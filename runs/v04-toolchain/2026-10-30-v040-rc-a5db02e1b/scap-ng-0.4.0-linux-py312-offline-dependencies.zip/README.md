# Offline Linux x86_64 CPython3.12 dependencies

Original unmodified hash-pinned wheels with embedded licenses/notices.
python -m venv /tmp/scap-ng-env
/tmp/scap-ng-env/bin/python -m pip install --no-index --find-links . --require-hashes -r requirements-linux-py312.lock
/tmp/scap-ng-env/bin/python -m pip check

Use with the exact source archive in the candidate decision packet. This is
not a Windows/macOS installation qualification or a project license grant.
