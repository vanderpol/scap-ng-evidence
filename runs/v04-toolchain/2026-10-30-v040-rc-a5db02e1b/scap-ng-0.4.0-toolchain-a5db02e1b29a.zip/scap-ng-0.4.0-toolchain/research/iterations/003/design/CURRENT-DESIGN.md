# Current SCAP-NG design

**Authoritative working-design checkpoint.** Historical experiments, generated trees, old proposal prose, and dated transition notes do not override this file. Material decisions should be reflected here when accepted by the project owner.

**Current status:** SCAP-NG 0.3.0 is the active pre-alpha development line. SCAP-NG 0.2.0 remains the frozen earlier review baseline at `7cd8b1242d7fb4a2eb9b5f49c7ec3f48b2dd622d`. Work intentionally deferred beyond the checkpoint is listed once in [deferred-after-0.3](../../../../specification/deferred-after-0.3.md).

## Architecture

- Compliance/vulnerability content uses **Benchmark → Rule → Assessment**. There is no separate Policy object/file.
- A Rule owns requirement/policy metadata, applicability references, named Assessment choices/selectors, and the default choice.
- **Owner-approved 2026-10-14 (#217):** The publisher default is the `default_assessment_choice` selector pointing to an existing, named Assessment choice (typically `automated` or `manual`). A duplicate `assessment_choices.default` entry is prohibited in 0.3 native authoring. Tailoring may select a publisher-declared alternate and cannot introduce arbitrary methods. For unusual source formats with distinct unselected checks, conversion SHALL preserve a uniquely named choice rather than silently changing its Assessment.
- An Assessment owns the automated or manual evaluation method.
- Rule policy disposition (including current `role` handling for informational use) is separate from Assessment technical truth.

## Profiles, Tailoring, Parameters, and input

- Benchmark membership enables Rules by default.
- Publisher Profiles are subtractive: they may disable Rules and do not re-enable ancestor-disabled Rules.
- External Tailoring may enable/disable existing Rules and choose among publisher-provided Assessment choices.
- Tailoring SHALL NOT replace Assessment implementations or override publisher Parameter values.
- Delegated organization-specific values use typed Organizational Input. A materially different requirement needs distinct policy identity.
- Tailoring provenance should identify purpose, creator/modifier/authorizer, dates, organization, and authorization reference/status.

## Native Assessment vocabulary

- Use **Assessment, Test, Object, State, Variable, and Item** where those concepts remain semantically aligned with OVAL.
- `evaluate` is the native replacement for OVAL `criteria/criterion`.
- Typed `*_title` metadata replaces generic OVAL `comment` presentation where appropriate.
- **Object** is authored resource selection/acquisition. **Collection** is the runtime act of evaluating an Object and producing Items plus status/completeness; it is not an authored synonym for Object.
- A Test may consume another first-class node directly when that is the natural semantic source; `variable.value` is the established example and does not require an artificial Object wrapper.
- Test, Object, and State/predicate capabilities remain independently typed where those nodes exist.
- Source/presentation mapping order has no execution meaning; forward references are valid. 0.3 does not introduce a new normative placement rule for `evaluate`; presentation order remains an authoring/editor concern.
- **Owner-approved 2026-10-14 (#200):** The 0.3 authoring language permits omitting ordinary scalar comparison `datatype` only when the native YAML scalar and capability contract uniquely resolve it. Specialized operations use single descriptive tokens (`version_greater_than`, `rpm_evr_equals`, `ipv4_subset_of`), never a separate `compare_as` property. Dynamic/array predicates and Variables/Organizational Inputs retain explicit types. Compiler expansion SHALL recover the original fully typed OVAL-compatible canonical predicates **before** capability/schema validation and .scapng emission. The older fully explicit 0.3 source stays supported; 0.2 stays frozen. This is an owner-approved pre-alpha Board-facing modernization, **not** a claim of Board ratification or complete independent OVAL scanner runtime conformance.
- Named internal component IDs use meaningful lowercase kebab-case with the component type as a required suffix: `-object`, `-state`, `-variable`, `-test`, and `-input`. Inline/private components do not receive artificial IDs. See [component naming](../../../../specification/assessment/component-naming.md).
- Private Objects and States are authored with their semantic consumer. Assessment-scoped reusable/referenceable acquisitions are declared under `shared_objects:`; use sites still use ordinary `object:` references.

## Variables, Sets, Filters, and dataflow

- **Variable minimization is a design requirement:** native authors SHOULD express literals, typed arrays, direct Assessment inputs, and collection iteration where they are sufficient, without pass-through Variables. Variables are retained where actual computation, dynamic dependency, source-semantic aggregation, or genuine reuse requires them.
- Conversion/normalization SHALL eliminate Variable indirection only when type, cardinality, result-state behavior, provenance and collection/evaluation semantics are preserved; unsupported cases stay explicit rather than being silently rewritten.
- Direct typed Assessment-input references (`value: {input: <declared-input-name>}`) in expected State values are a **0.3 authoring requirement**. A pass-through Variable SHALL NOT be required. Type/cardinality compatibility, explicit multi-value quantifiers, missing-input propagation, bound-Parameter provenance and consumer-reference validation SHALL be enforced before declaring execution conformance.
- Direct scalar and typed literal-array Object/State values replace source-time static Variable plumbing where exact and source-equivalent quantifier semantics are explicit.
- Variables may reference named Objects, other Variables, or contain private embedded resource selection where supported; keep named Variables for genuine runtime derivation, chaining, external/runtime dataflow, or meaningful reuse.
- Lossless conversion preserves meaningful shared Object boundaries and Variable dependency graphs; it does not duplicate a shared source Object merely for convenience.
- Sets, Filters, object/variable components, functions, existence/cardinality, datatypes, comparisons, records, and dependency behavior must retain their effective semantics.
- **0.3 terminology decision:** the expected-operand multi-value quantifier is `value_match`, for literal arrays, direct Assessment inputs, and Variables. It preserves source OVAL `var_check` meaning and is independent of observed-value `match`/`existence`. Converter, schema and example alignment is in [#194](https://github.com/vanderpol/scap-ng/issues/194); release validation is still required.
- `for_each` is native collection expansion over collected Object/Item data. It is not evaluation iteration and SHALL preserve the original Test aggregation/existence boundary.
- Nested `for_each` is part of the 0.3 requirement set. Inner collection scope must be explicit, outer-binding lineage preserved, correlation semantics deterministic, implicit Cartesian behavior forbidden, and incomplete/error/cycle/resource-limit behavior normative.
- Shared Observation is deferred beyond normative 0.3. Cross-Assessment reusable acquisition remains research until its export/result/provenance/binding/manifest/cache contracts are complete.
- Source identity remains available in migration provenance so distinct source nodes are not merged merely because payloads happen to match.

## Applicability and conditionals

- Applicability is explicit authored assessment logic, not hidden scanner OS/domain-role classification.
- CPE/platform identifiers are naming/mapping metadata unless backed by executable applicability logic.
- The inherited narrow `if/then/else` evaluation form is retained unchanged from 0.2.
- Broader case/elseif/procedural conditional syntax is not part of 0.3.
- Existing Boolean OVAL logic SHALL NOT be automatically rewritten as conditional execution merely because it appears equivalent; six-state outcomes, collection, evidence, and scheduling can differ.

## OVAL/SCAP migration

- **Owner-approved 2026-10-24, 0.4.0 only ([#251](https://github.com/vanderpol/scap-ng/issues/251#issuecomment-6388735943)):** Test-level `all_exist` may intentionally normalize to `items_found: one_or_more` under the versioned actual-Items collection contract, without synthetic nonexistent Items and without dropping error/unknown collection evidence. This is not unrestricted OVAL truth-table equivalence. Preserve original Test/Object identities, attributes, versions and hashes, plus normalization scope/reason, in provenance; field/record semantics are unchanged. The shared converter currently admits the source-proven pinned RHEL 9 case only. See the [review and implementation packet](../../../../docs/audit/v04-owner-decisions-integration.md).
- Faithful conversion does not infer Benchmark Group taxonomy by default.
- Conversion tools MAY expose explicit opt-in automatic grouping (currently `--auto-map-groups`) for editorial normalization.
- Automatic grouping SHALL use only high-confidence mappings; uncertain Rules remain ungrouped rather than being forced into a catch-all Group.
- Group membership SHALL NOT alter Rule applicability, selection, Assessment behavior, Parameters, scoring, remediation, or result semantics.
- Forward migration from SCAP 1.4 is mandatory.
- OVAL 5.12.3 is the current semantic migration baseline, with later authoritative corrections/reinstatements handled explicitly.
- OVAL 6 is used primarily to identify genuinely new Test/Object/State/Item semantics; it is not an intermediate runtime format.
- Features exercised by current published content or conformance content are preserved unless a compelling explicit disposition documents an equivalent replacement/removal.
- Effectively deprecated OVAL Tests are conversion blockers; native Assessments do not carry a `deprecated` runtime flag.
- Source defects are preserved/reported as source defects rather than silently repaired during equivalence conversion.
- Existing OVAL platform-family distinctions remain where collected-data/evaluation semantics materially differ.

## Native capability design

- Preserve semantics, not XML type hierarchies, wrapper elements, namespace mechanics, or historical serialization workarounds.
- Reuse shared native primitives for comparison, quantifiers, existence/cardinality, records, Sets/Filters, traversal, and result behavior rather than duplicating them per capability.
- Native capability names may remove obsolete historical numeric/version suffixes when reviewed semantics justify it; exact OVAL source identity remains in provenance.
- Publisher/vendor extensions must remain isolated and cannot silently redefine core behavior.

## Provenance and native-source cleanliness

- Native source carries concise author/publisher provenance where reliably derivable. This metadata is non-executable and does not replace logical IDs or migration evidence.

- Executable native Benchmark/Rule/Assessment/Object content does not embed XCCDF/OVAL/OCIL/CPE XML IDs, namespaces, href graphs, converter diagnostics, parity traces, or skipped-source-defect records merely for migration traceability.
- Conversion/normalization evidence is emitted separately and may reference native logical IDs.
- Native content must remain executable without migration evidence.

## Results and evidence

- Results separate policy/Rule context from distinct Assessment executions and their Test/Object/Variable/Item evidence.
- Assessment Results are standalone, Test-centered technical reports: each retained per-Item observation and its typed system fields sits beside the Test's verdict and comparison, even if a shared observation is repeated under different Tests. Runtime collection caching is independent of result serialization.
- The scanner application/run controls per-Test evidence retention; it may request a diagnostic override against the **same signed Benchmark and Assessment content**. The effective cap, source and override explanation are in Assessment Results, and reporting limits never alter evaluation truth, redaction or safety limits.
- Execution identity, dependency scheduling, provenance, completeness, and outcome rationale are explicit.
- Evidence caps or early termination may bound volume but must record completeness/truncation and must not change the normative verdict.
- `reported_elements` is an explicit author-visible reporting projection and does not change technical truth; hidden capability-specific reporting defaults are not part of 0.3.
- 0.3 defines one canonical result contract rather than separate normative thin/full profiles; projections/export choices may vary without changing truth.
- Manual Assessment Results require the human assessor identity and assessment time, with organization/contact/evidence context available as appropriate.
- Schema/representation validity, known-result evaluation, acquisition/collector conformance, live-target testing, migration equivalence, human acceptance, and Board ratification are separate evidence levels.

## Packaging

- Compiled content uses a manifest-authoritative logical object graph.
- The current preferred container is deterministic ZIP with the `.scapng` extension.
- Archive paths are storage locations, not semantic identity; logical IDs resolve through the manifest.
- Migration/normalization evidence is not packaged by default.
- 0.3 requires one simple interoperable signing/integrity path over deterministic bytes or a deterministic manifest-bound package/result. HSM/CAC/TPM/backend integration is an implementation concern rather than alternate content semantics.

## Frozen 0.2.0 review baseline

- The 0.2.0 schema meaning is frozen at `7cd8b1242d7fb4a2eb9b5f49c7ec3f48b2dd622d`; new semantic work belongs to 0.3.0.
- The six converter-produced Board cases under `board/review-content/0.2.0/` are pending human acceptance.
- ESX/VMware expansion and the two Kubernetes OVAL 6-only Tests are deferred pending recorded guidance/decisions.
- Full runtime equivalence remains unproven; round-trip/source-reference/schema checks alone do not establish scanner equivalence.
- Content/conformance work precedes editor development.

## Required working procedure

1. Start from current `main` and this design contract.
2. Use pinned original SCAP/OVAL input for conversion work; do not normalize stale generated output and call it a fresh conversion.
3. Reduce defects/ambiguities to small independently reasoned fixtures.
4. Run focused tests first, then the fast five-benchmark integration lane when appropriate.
5. Record source pins, commands, outcomes, limits, and human-review status.
6. Do not encode a materially ambiguous semantic choice merely because one implementation passes tests.
7. Use the full NIWC corpus only for intentional milestones/freezes/Board deliverables.

See [MAINTAINING.md](../../../../MAINTAINING.md) for the human acceptance process, [the 0.2.0 freeze record](../../../../transition/0.2.0-freeze-record-2026-10-04.md) for technical evidence, and [review/current](../../../../review/current/README.md) for current review questions.
