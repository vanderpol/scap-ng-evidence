# SCAP-NG 0.4 engineering execution ledger

Authority: [owner directive](https://github.com/vanderpol/scap-ng/issues/251#issuecomment-6401652271).
This ledger records bounded engineering outcomes; it grants no production-release,
signing/trust or scanner acceptance authority. No paid capacity is purchased or
assumed available. No Goal/schedule/auto-resume state is claimed from unobserved UI.

## Active assignment — complete the approved direct converter

Owner scope: original Independent/Linux/UNIX/Windows OVAL 5.12.3 for the six
representative STIGs. Continue across verified commits; no production release,
normative redesign, macOS expansion or deprecated-WMI upgrading. Source-invalid
and unresolved all_exist cases remain blocked. Current schema, original XSD/
Schematron/XML and independent source/compiled operands are separate gates.

Phase 1 [requirements](v04-six-source-requirements.md): all 1,567 original Rules,
1,396 OVAL-bearing and 171 manual/OCIL-only; 2,140 declared Tests and 2,695
Definitions. Exact dependencies, node-level source validity, applicability/CPE
trees, missing capabilities and potential unlocks are inventoried. Apache/DNS
have 63 broken primary catalog bindings; matching candidate graphs are evidence
only and do not repair source. Eleven primary OVAL closures have original
XSD/Schematron violations (including two among the already broken DNS bindings).
No capability enabled or prior primary source proof changed by this inventory.

Native schema-generator decoupling is complete at `b225b7eba`: all 100 generated
contracts retain exact parity, all 31 triggered hosted checks pass, and mandatory
regressions pass 3,118 tests with one existing skip and zero failures/errors.
The [generic capability batch](v04-direct-capability-batch.md) enables five more
ordinary capabilities without new capability-specific conversion algorithms.
The first complete primary-source acceptance pass proves/compiles 816 closures;
all 249 prior Server 2025 program hashes match. Applicability remains unproved,
580 primary Rules remain blocked/unverified and 171 are manual/OCIL-only.
At `44254953b`, twelve focused tests and all ten hosted workflows pass. Hosted
mandatory results: **3,130 tests, zero failures/errors, one existing skip**; both
mandatory and six-source artifact digests are verified. All 816 primary proofs
and exact programs pass hosted retention. Local maintained/supplemental details
are in the linked report.

Owner execution correction (2026-10-27): complete shared OVAL features using the
pinned Test Content, then apply them across capabilities through mappings.
Capability-specific implementation is justified only by demonstrated collection
semantics; ordinary element names are data. Next specific action: batch the
remaining ordinary scalar proof contracts, then shared Variable-source and
aggregation (`merge`/`unique`) support, followed by file traversal and RPM scalar
behavior routing. Use one documented upgrade entry point and preserve the
816-proof/program floor. Do not turn each Test into an implementation project.
The assignment remains active; Phase 1 is not completion of the converter.

Recovery on 2026-10-27 found a clean checkout at `44254953b`, with no local-only
implementation. Fast-forwarded to published evidence `609da701f`; preserved
workspace scratch and both whitespace-only unreachable blobs. See the
[recovery record](v04-recovery-2026-10-27.md). The next
[ordinary scalar batch](v04-direct-scalar-expansion.md) enables ten mappings
through data only: 46 pinned focused Tests pass, complete configured corpus
274 attempted / 227 compiled / 210 independently proved. Six-source retention
and mandatory/hosted gates remain pending this implementation checkpoint.

Scalar six-original local verification subsequently completed: **820 proved**,
four additional closures (two RHEL, two Oracle); every original 816 proof/program
passes retention. Windows 11/Server remain 218/249. Apache/DNS remain blocked
by the original bindings. Next shared Variable increment passes six focused
tests and the 29-test related suite: 21 original cases compile/prove; invalid
integer constants, all_exist, separate identity predicates, casts and unsupported
aggregation/source composition remain blocked. Original fixture hashes and
reproduction instructions are in the developer guide; full gates pending.

The shared traversal/scalar-behavior checkpoint adds UNIX file and RPM-info
conversion, source-field projection aliases, original-XSD behavior defaults and
the existing CLI's `--verify` mode. Six Variable tests, five file tests (16
original cases), three scalar-behavior tests (three original cases), and two
verified-CLI tests pass. The CLI packages only proved closures, independently
consumes the package, inventories all Rule outcomes and refuses output overwrite.
The retained singleton-function test now positively proves multivalue collections
instead of expecting the formerly unsupported case to fail; its identity remains.

**Owner decision, 2026-10-27: approved exact-alternative correction.** The
[review packet](v04-process-selector-schema-conflict.md) records the valid original
counterexample and dated authorization. `flat_object` retains `oneOf` and Set/direct
restrictions while excluding absent selectors from each direct alternative.
The [all-100 audit](v04-exact-selector-contracts.md) finds exactly ten explained
Object-variant changes, 90 byte-identical contracts, zero unexpected differences,
and unchanged Set branches. Only those ten parity hashes update. All eight original
process Tests validate, compile and independently prove using ordinary activation
and frozen scalar identities. **21 focused tests pass**. Normative schemas, source,
mappings, compiler semantics and scanner behavior are unchanged. Fresh maintained,
six-source and full pinned-corpus gates are running before commit/push; the earlier
pre-correction full process retained the old generator and had one parity-lock
failure, so it is not a passing corrected-tree run. Continue the approved queue
after successful verification and publication, as explicitly authorized by owner.

Verification is now PASS: **3,155 mandatory tests, zero failures/errors, one existing
skip**, plus three separately passed new snapshot-retention guards. Selection
reconciliation accounts for every one of **3,158 current identities**, none lost.
The final six-original gate proves/compiles **1,001** primary closures (RHEL 269,
Oracle 264, Windows 11 219, Server 249), independently consumes all four packages,
and retains every original 816 program hash. The floor now protects all 1,001.
395 primary cases remain blocked/unverified, 171 Rules are manual/OCIL-only,
applicability stays unproved and Apache/DNS retain all 63 broken bindings.
The full 803-Test audit reports **629 configured / 339 compiled / 318 proved**;
the wider diagnostic visitor compiles 433, proving 318, with no schema-invalid
converted cases. [Machine receipt](v04-recovery-resumption.json).

At published `615cd6e49`, eight hosted workflows pass; the UNIX-password lane alone
failed because a directory equality check rejected four additional proved closures.
Its six pinned original snapshots are unchanged. The retention guard now requires
all old bytes unchanged while allowing additional proved cases; empty baselines,
tampering, removal and output overwrite fail. Local complete lane passes six
retained/four additional. Corrected-head CI follows commit/push. Next bounded
implementation: the reproduced seven ordinary mapping/proof recipes (28 original
Test proofs, currently inactive), then remaining shared source forms/functions.

| Checkpoint | BASE_SHA / RESULT_SHA | IMPLEMENTED | SOURCE_PROVED / COMPILED_UNPROVED / BLOCKED | REGRESSIONS / TESTS / CI | PERF / NEXT |
| --- | --- | --- | --- | --- | --- |
| Architecture acceptance — complete | `284705ee6` / `840242a14` | Common Set proof; integer GT/GTE/LTE; public validation profiler | 87 / 0 / 204 of 291 | Zero; 3,008 tests, one unchanged skip; all five implementation checks PASS | Validation branching dominates; no optimization claimed. GO audit-policy source increment. |
| Audit policy — complete | `02b50ec57` / `ad6df4f71` | Approved implicit-system source; audit enum/field proof | 130 / 0 / 161 of 291 | Zero; 3,012 tests, one unchanged skip; all five implementation checks PASS | 262-doc validation 11.532 s (32.178 s profiled), no speedup claim. GO closed-domain Registry selector proof. |

The [authoring acceptance checkpoint](v04-direct-authoring-acceptance.md) is complete:
`9c48e684f` → `da227c462`, with examples published in `1f8098a95`.
Assessment-local sharing, safe YAML presentation and capability inheritance are
verified: 95 inline Test Objects, one named Object/seven Test references, 71
no-Object Tests and 101 compact Registry Object sites. Coverage remains
130 source-proved / zero compiled-unproved / 161 blocked. There were no avoidable
shared declarations in this pin; controlled source-backed graphs establish the
corrected policy. Mandatory regressions: 3,021 tests, zero failures/errors, one
unchanged skip; final style checks 9/9. All four triggered implementation CI checks
and both example-publication checks passed. No speedup/coverage gain is claimed.
The one final issue-comment attempt returned `Post "https://api.github.com/graphql": Forbidden`;
the linked committed report is the fallback, with no retry.

[Architecture packet and evidence](v04-architecture-acceptance.md) contains exact
SHAs, source hashes, proof cases and CI links. [Audit-policy packet](v04-audit-policy-direct.md)
records its completed increment.

The [closed-domain Registry hive checkpoint](v04-direct-registry-hive.md) is now
complete: `cef742119` → `2c850a36b`. All 19 additional original Rule closures
independently prove and compile; the 49-pair original Object/Item enum relation
is explicit and source tokens remain in provenance. Current coverage is
**149 proved / zero compiled-unproved / 142 blocked** of 291. All prior 130 program
hashes are unchanged. Mandatory regressions: **3,026 tests**, zero failures/errors,
one unchanged skip; all five exact implementation-head workflows PASS. Authoring
remains local by default: 114 inline Test Objects, one named Object/seven references,
71 intentional no-Object Tests and 120 compact Registry Object sites. Public gates
validate 300 JSON/300 YAML documents and independently verify 149 programs.
Empty/dynamic hives, State-level enum comparator changes and extra `all_exist`
normalizations remain blocked. No unmatched-workload speedup is claimed.

The [user-rights checkpoint](v04-direct-userright.md) is complete:
`a2ce5fd94` → `c80f84c0a`, with actual examples in `718b10df1`.
Of 39 original candidate closures, 34 independently prove and compile; five
remain atomically blocked by WMI record dependencies. Global coverage advances
to **183 proved / zero compiled-unproved / 108 blocked** of 291; all prior 149
program hashes are preserved. **3,032** maintained tests pass with zero
failures/errors and one unchanged skip; all five implementation-head workflows
PASS. The published Variable/Filter case retains original `var_check: all` as
`value_match: every`; it is never changed to match an apparent policy intent.
Public gates validate 368 JSON/368 YAML documents and verify 183 programs.
Authoring: 147 inline Test Objects, nine shared references to two named Objects,
71 intentional no-Object Tests and 120 compact Registry Object sites. No schema,
production converter/compiler or release gate changed. One issue-comment attempt
returned `Post "https://api.github.com/graphql": Forbidden`; no retry was made.

The [WMI record checkpoint](v04-direct-wmi-records.md) is complete:
`f9e3b0978` → `4087e4309`, with [actual WMI examples](../examples/direct-wmi/README.md)
published in `e5bd741f9`. All **18** supported WMI closures independently prove
and compile, completing all **39** user-rights candidates. Eight WMI closures
remain blocked by unsupported capabilities or unapproved `all_exist`. Current
coverage is **201 proved / zero compiled-unproved / 90 blocked** of 291; all
183 prior program hashes are unchanged. **3,037 tests**, zero failures/errors,
one unchanged skip; all five exact implementation-head hosted workflows PASS.
Public paired gates validate 404 JSON/404 YAML documents and independently verify
201 programs. Authoring remains local by default: 165 inline Test Objects, 36
references to 12 genuinely shared Objects, 71 no-Object Tests and 120 compact
Registry Object sites. Named record boundaries, original datatype distinctions
and missing-member errors remain intact. No schema or release-gate changes.

The [password/lockout-policy checkpoint](v04-direct-system-policy.md) is complete:
`e5bd741f9` → `88eaa0133` → corrected `740bc8039`. All seven password-policy and
three lockout-policy original closures prove and compile; coverage advances to
**211 proved / zero compiled-unproved / 80 blocked**. All prior 201 program hashes
are unchanged. Public gates validate 424 JSON/424 YAML documents and verify 211
programs. Initial local mandatory tests: **3,043**, zero failures/errors, one
unchanged skip; corrected targeted tests 6/6; all five exact corrected-head hosted
checks PASS. Internal review caught and corrected required fixed datatype
attributes being mistaken for defaults; both readers now reject omissions. The
actual original source already has explicit valid attributes, so all 424 generated
documents are unchanged. No source normalization or schema modification.

The [Windows service checkpoint](v04-direct-service.md) is complete:
`740bc8039` → `fefbcc3a9`. Both actual source closures prove and compile; coverage
advances to **213 proved / zero compiled-unproved / 78 blocked**. All previous
211 program hashes are unchanged. Public gates validate 428 JSON/428 YAML
documents and independently verify 213 programs. **3,047** maintained tests,
zero failures/errors, one existing skip; 52 related tests and 15 final focused
tests pass. All five exact implementation-head hosted workflows PASS. Source
selector case semantics, API enum names and relative-COMPLEMENT/Filter boundaries
remain exact. Authoring: 167 inline Test Objects, 36 references to 12 genuinely
shared Objects, 85 no-Object Tests, 120 compact Registry Objects; deprecated keys
zero. The final trace qualifies unsupported record constructs accurately.

The [OpenSSH text-file checkpoint](v04-direct-textfile.md) is complete:
`ca1ee36f3` → `4adfdbad9`; [actual YAML/JSON](../examples/direct-textfile/README.md)
is pinned in `fd66890da`. All seven original candidate closures prove and compile;
coverage advances to **220 proved / zero compiled-unproved / 71 blocked**. All
213 previous program hashes remain unchanged. Public gates validate 442 JSON/442
YAML documents and independently verify 220 programs. **3,052** maintained tests,
zero failures/errors, one existing skip; 57 related tests pass; all five exact
implementation-head workflows PASS. Regex flags/defaults, item creation,
filesystem scope, capture types and original patterns remain exact. Unsupported
Windows-view/traversal attributes fail closed. Authoring: 174 inline Test Objects,
36 references to 12 genuinely shared Objects, 85 no-Object Tests and 120 compact
Registry Objects; deprecated grammar zero.

The [file-effective-rights checkpoint](v04-direct-file-rights.md) is complete:
`95ce4e721` → `6d7fdc039`; [actual Set/Filter/Variable samples](../examples/direct-file-rights/README.md)
are pinned in `97a151f08`. All eight original closures prove and compile;
coverage advances to **228 proved / zero compiled-unproved / 63 blocked**. All
220 previous program hashes remain unchanged. Public gates validate 458 JSON/458
YAML documents and independently verify 228 programs. **3,057** maintained tests,
zero failures/errors, one existing skip; 62 related tests and 20 final publication
checks pass. All five exact implementation-head workflows PASS. SID selection,
permission Booleans, Variables, path forms, Filters and relative-complement
boundaries remain exact. Unsupported group expansion/view/traversal/nilled
selection stays blocked. Authoring: 200 inline Test Objects, 39 references to
15 genuinely shared Objects, 85 no-Object Tests, 127 compact Registry sites;
deprecated grammar zero. The sample helper now handles complex-only selections
and distinct roles without inventing ordinary examples or repeating a Rule.

The [command collection-error checkpoint](v04-direct-command-behaviors.md) is complete:
`083ec0e3e` → `fab566b2a`; [actual error-flag YAML/JSON](../examples/direct-command-behaviors/README.md)
is pinned in `b9e6a7af3`. All ten actual closures prove and compile; coverage is
**238 proved / zero compiled-unproved / 53 blocked**. All 228 previous program
hashes remain unchanged. Public gates validate 478 JSON/478 YAML documents and
verify 238 programs. **3,061** maintained tests, zero failures/errors, one existing
skip; 66 related tests pass; all five exact implementation-head workflows PASS.
True error flags remain collection controls; neighboring default flags stay false.
Historical fixed case windows-14/SV-278146 now proves without changing its fixture
or old manifest; the original reader remains unverifiable and a false-flag mutant
mismatches. The 883-Assessment ledger is unchanged. Authoring: 211 inline Test
Objects, 39 references to 15 shared Objects, 85 no-Object Tests, 127 compact Registry
sites; deprecated grammar zero.

The [cmdlet checkpoint](v04-direct-cmdlet.md) is complete:
`600fa14cb` → `c117b06c8`; [actual nullable/input-record YAML/JSON](../examples/direct-cmdlet/README.md)
is pinned in `8967d7d8c`. All seven actual closures prove and compile, including
two mixed WMI closures; coverage is **245 proved / zero compiled-unproved / 46
blocked**. All 238 previous program hashes remain unchanged. Public gates validate
492 JSON/492 YAML documents and verify 245 programs. **3,066** maintained tests,
zero failures/errors, one unchanged skip; 71 related tests pass; all five exact
implementation-head workflows PASS. Null module constraints, invocation field
selection, expected-value cardinality and result records remain distinct.
Capability-specific cmdlet select is validated as an input record; generic wrappers
remain invalid. Authoring: 221 inline Test Objects, 43 references to 17 shared
Objects, 85 no-Object Tests, 127 compact Registry sites; deprecated grammar zero.

The [remaining Windows primitives checkpoint](v04-direct-remaining-primitives.md)
is complete: implementation `c721ed0f6` has all five exact-head hosted workflows
PASS. [Actual IIS/NTUSER YAML/JSON](../examples/README.md) is published in
`a5743a96a`. Five new
actual source closures prove and compile: IIS appcmd/listconfig, current-process
environment dependencies, NTUSER, and case-insensitive account-name inequality.
One preceding admission is withdrawn: SV-278031 omits the original Schematron's
required datatype on nil cmdlet parameters. Both readers now reject that malformed
source; a controlled explicitly typed derivative proves but adds no coverage.
The historical UEFI example/report is preserved and marked superseded.

Current coverage is **249 proved / zero compiled-unproved / 42 blocked** of 291:
30 OCIL-only Rules (no OVAL check), eight unapproved all_exist, one unmapped legacy
user acquisition, one deprecated scalar-WMI/function closure, and two source-invalid
cases (nil record and pattern-path recursion). Independent original XML census
finds **261 OVAL-bearing Rules**, with **249 proved / 12 blocked**; all 291 original
Rules and 843 checks remain inventoried. All **244 retained** previous
program hashes are unchanged. All 39 user-rights closures remain proved. Public
gates validate **500 JSON/500 YAML** documents and independently verify 249 programs.
**3,074** mandatory tests, zero failures/errors, one unchanged skip; 79 related
tests PASS. Authoring: 249 Assessments/357 Tests, 229 inline Test Objects, 43
references to 17 genuinely shared Objects, 85 no-Object Tests, 128 compact Registry
sites; deprecated grammar zero. This adds 100 source-proved Rules over reviewed
`a2ce5fd94`, without changing the 883-Assessment package ledger.

Source counterexamples retain original XML, IDs and SHA-256 references; neither
source repair nor new normalization is applied. Restoring the source-invalid
cases requires corrected pinned input or explicit owner review. Historical evidence
and mandatory gates remain intact. Issue commenting was previously Forbidden;
committed reports remain the authorized GitHub handoff. No scheduled/automatic
resumption, scanner acceptance, signing/trust or release readiness is claimed.

The [100-capability generic architecture audit](v04-generic-capability-audit.md)
classifies all mappings without enabling additional conversion: **60** flat-selector
and **17** implicit-system shapes; **11** traversal, **7** collector-behavior,
**3** remaining record/input and **2** special Test-source shapes. The **77/23**
split is structural, not complete-capability certification. Current direct catalog
remains 15; source coverage remains 249/0/42. Shared XSD/Schematron validation,
datatypes/operators, records, traversal and consistent canonical metadata routing
should replace per-capability procedural expansion. Seven historical traversal
crosswalks say any where the approved common schema requires all; nineteen Object
crosswalks retain old select/collect paths. No schema, mapping or converter was
changed by this read-only audit; the CSV/machine packet preserve all 100 rows.

The [canonical metadata/schema synchronization checkpoint](v04-schema-converter-sync.md)
is reconciled at `ceb2e6aadd0c855aadf912841c81d2c7bc979703`. Twenty-seven mapping metadata files
now use flat Object paths and canonical filesystem scope. All 30 normative schema
files, 100 generated validation structures, 500 authoring documents and 249 prior
program hashes are unchanged. The real cmdlet select record remains valid and is
explicitly tested alongside rejected generic wrappers. Source coverage is still
249/0/42; no new capability is enabled. A schema/mapping-change workflow now
regenerates contract data, checks targets and runs pinned source regressions.
Missing source correspondence is reported, not guessed. Initial maintained run:
3081 tests, one stale-citation failure, zero errors, one unchanged skip; both raw
metadata anchors were rolled forward with previous hashes/revision preserved.
The affected 18 proof tests and seven final contract tests pass; no assertion was
relaxed. The old public schema-generator adaptation remains documented debt.

The [exact-head CI reconciliation](v04-ceb2-ci-reconciliation.md) independently
retrieved the hosted mandatory artifact: **3,081 run, 3,080 passed, one existing
skip, zero failures/errors**, with its ZIP digest verified against GitHub.
The final local maintained run independently matches all 3,081 selected test IDs,
zero failures/errors and the same skip; public package/parity acceptance passes.
All 18 hosted workflows completed: **12 success / six failure**. The six original
Windows shellcommand, WMI57, cmdlet, cmdlet Variable, Set/Filter and published
Bluetooth proofs fail on older native grammar at both unchanged `52efe1195` and
`ceb2e6a`; exact authenticated hosted errors and baseline reproductions are recorded.
They remain visible and unchanged. In particular, the immutable October 21
Bluetooth package cannot validate unchanged against today's schema. Its historical
versus current-derivative acceptance target needs explicit reconciliation before
claiming all-green CI. No output, source proof, workflow gate or normative schema
was changed by this documentation checkpoint. Generator decoupling is deferred
until the owner's fully-green prerequisite is met.

Owner-authorized follow-up: [current-source acceptance](v04-current-source-acceptance.md)
preserves the Bluetooth archive under its historical contract and introduces a
separate original-SCAP-derived current acceptance proof. Five source obligations
retain their original pins, assertions, reverse proofs and negative controls.
Seven new and 31 related focused tests pass, including current compilation,
independent package operands and explicit deprecated-WMI rejection. WMI57 exposed
a deterministic record-field-index roundtrip defect; sorting that derived map
index preserves source/Boolean semantics. Full maintained/hosted CI results will
be reconciled before generator decoupling. Source coverage remains 249/0/42;
neither the 883 ledger nor a full Benchmark release is promoted by these proofs.

At `a3e30e27fc9e65a5fda331a88efaea984d12fc1d`, local and hosted maintained runs
both pass **3,088 tests**, zero failures/errors and one existing skip; selected
IDs and the hosted artifact digest match. Fifteen triggered current workflows
and the separate pinned archival job pass. A generator-trigger preflight also
records ten older red workflows not triggered by that commit, including the
immutable 4,001-document archive gate. Their obligations remain visible and
must be reconciled before claiming a globally green generator prerequisite.

The [generator-trigger reconciliation](v04-generator-trigger-reconciliation.md)
retains nine more original-source obligations (21 Definitions / 182 Tests) and
separates immutable 4,001-file archival validation from the already-approved
4,012-document current review-format replay. No benchmark packages are rebuilt.
The latter exposed missed Filter-count migration inside Variable acquisitions;
the existing Object visitor now handles those explicit migrations without
touching literal records. Forty-two focused tests and all source CLI gates pass;
full maintained/hosted results are reconciled before generator work. No new fresh
source all_exist normalization or deprecated-WMI admission is introduced.

At `8834539967`, both final local and downloaded hosted maintained results are
**3,090 tests, zero failures/errors, one existing skip**. All 24 triggered current
workflows and the separate opt-in archive job succeeded. Exact run IDs and the
artifact digest are in the trigger-reconciliation packet. This satisfies the
current-source CI prerequisite. The parity-preserving generator candidate remains
isolated outside the repository while the owner-requested complete pinned OVAL
Test Content coverage measurement is completed; no converter admission is expanded.

The [complete OVAL Test Content coverage audit](v04-oval-test-corpus.md) inventories
803 Tests in 145 OVAL documents; all 154 file blobs match the upstream Git tree.
The unchanged enabled 15-capability baseline remains 144 compiled / 127 proved
of 190 attempts. A separate metadata-only generic probe passes all 83 approved
non-macOS mappings (81 represented) to the same visitor: 768 attempts, 329 converted,
297 schema-valid/compiled, 133 independently proved, 153 proof-unsupported and 11
term mismatches. Thirty macOS-specific and five unmapped Tests stay reference-only.
All 43 Tests in macOS source files remain pinned; generic Unix/independent cases
there add no macOS capability implementation. No schema, production capability,
source proof or Windows Rule admission changes. Exact errors, invalid authoring,
closure inventory and hosted evidence are linked from the report.

At corpus implementation `f2d68bf2032bdee7819be425b58ccd224ef7145f`, all six
triggered hosted workflows pass. The downloaded maintained result reports
**3,102 tests, zero failures/errors, one existing skip**, with every prior
maintained identity retained. The complete hosted coverage artifact matches
all local non-timing evidence. Twelve focused tests pass. Source inputs,
schemas, converter/compiler/proof-reader files and production admission remain
unchanged. Native-generator decoupling is still the next implementation objective;
the isolated candidate has full dictionary parity for 100 generated contracts
but is not integrated or claimed as completed.

Native generation checkpoint: [report](v04-native-generator.md). Local full
100-contract fingerprint parity, public import isolation/compilation, 803-case
corpus hash/outcome parity, 33 focused tests and eight promotion checks pass.
Active generation modules shrink from 1,188 to 487 nonblank/noncomment lines.
No capability admission or normative schema changes in that checkpoint. All 31
exact-head hosted workflows pass, including 3,118 mandatory tests with one skip.
The subsequent five-capability batch and source-proof expansion are recorded above.
