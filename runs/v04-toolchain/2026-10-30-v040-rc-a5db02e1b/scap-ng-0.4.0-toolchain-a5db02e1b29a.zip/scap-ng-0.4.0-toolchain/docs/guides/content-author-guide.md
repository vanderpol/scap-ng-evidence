# SCAP-NG Content Author Guide

For reproducible 0.4.0 source conversion and worked CLI commands, use the
[candidate operator guide](../releases/0.4.0-rc.md). The candidate ledger
separates compiled/static-proved native content, unverified native drafts,
blocked originals and preserved manual content. Review source-trace warnings
before reusing generated content. A compiled draft is not a scanner result.

**Status: 0.4.0 pre-alpha draft.** This is a short introduction to the current authoring model, not a substitute for the [versioned schema](../../schema/v0.4.0/README.md) or [specification](../../specification/README.md). Track corrections and review questions in [#252](https://github.com/vanderpol/scap-ng/issues/252).

## 1. Start with the policy

Read SCAP-NG from the outside inward:

| Part | Purpose |
| --- | --- |
| **Benchmark** | Defines the publisher's policy, target Platform, and member Rules. |
| **Rule** | Defines one requirement and its Assessment choices. |
| **Assessment** | Defines the method used to determine the relevant fact or requirement outcome. |
| **Result** | Records what was evaluated, the outcome, and supporting explanation/evidence. |

A Benchmark's Rule membership defines its baseline. A publisher Profile can deselect member Rules; external Tailoring is a separate policy layer. Organizational Input supplies authorized expected-state data and is not the same as Tailoring. These distinctions are explained in [Benchmark/Rule](../../specification/policy/benchmark.md), [Profiles/Tailoring](../../specification/policy/profiles-and-tailoring.md), and [Parameters/Organizational Input](../../specification/policy/parameters-and-organizational-input.md).

### Platform, applicability, compliance

These are separate decisions: **Platform** asks whether the target is within the Benchmark's product scope; **Rule applicability** asks whether a selected Rule concerns that target; **compliance** asks whether an applicable Rule is satisfied. An external identifier such as CPE is not executable proof by itself; the Platform identifier must bind to an Assessment. See [Platform and applicability](../../specification/policy/platform-and-applicability.md).

## 2. Select an Assessment method

A Rule may declare named manual and automated choices. Its `default_assessment_choice` names the publisher's selected default; other declared choices remain available under the rules of the [Assessment choice model](../../specification/policy/benchmark.md). A manual Assessment records a human procedure. An automated Assessment expresses technical collection and evaluation. See [manual assessments](../../specification/assessment/manual-assessment.md) and [assessment methods](../../specification/assessment/assessment-method.md).

## 3. Read an automated Assessment

An automated Assessment combines Tests through `evaluate`. A Test names a collection `capability`, selects data with `object`, and states the expected conditions with `require`.

The following is a **short syntax illustration**, not a complete STIG Assessment:

```yaml
tests:
  home-mount-requires-nosuid-test:
    test_title: The /home mount must use nosuid
    capability: linux.partition
    object: {mount_point: {equals: /home}}
    require:
      items: one_or_more
      all_items_must:
        - mount_options:
            require: at_least_one_exists_and_all_match
            equals: nosuid

evaluate:
  test: home-mount-requires-nosuid-test
```

Here, `object` selects the mount, `items` constrains the collected Item population, and the field condition constrains `mount_options`. **Item existence is not the same as field existence or matching.** Collection failure is not an empty population. For current syntax and source-backed full examples, use the [0.4.0 Assessment examples](../../specification/examples/assessments.md) and their pinned release.

More complex Assessments may use multiple Tests, logical composition, Variables, Sets, Filters, and nested record conditions. Consult the exact [0.4.0 schema](../../schema/v0.4.0/README.md) before writing them; avoid replacing uncommon source-proven behavior with an attractive but unproved shortcut.

## 4. Manual checks and organization-supplied values

A procedure-only Manual Assessment needs an Assessment ID, `mode: manual`, and a human-readable `procedure`. The processor presents the procedure and records the operator's completed outcome and provenance; it does not infer the verdict from prose. See [Manual Assessment](../../specification/assessment/manual-assessment.md).

A **Parameter** is policy data, not an Assessment Variable. When a publisher expressly leaves an expected value to an organization, **Organizational Input** supplies it through an authorized, validated binding. It cannot override an existing publisher requirement. See [Parameters and Organizational Input](../../specification/policy/parameters-and-organizational-input.md).

## 5. Interpret results without losing meaning

A Rule Result communicates a policy-facing outcome, while Assessment details and evidence explain the technical evaluation. Scoring disposition is separate from technical truth. The current 0.4.0 draft [Rule Result schema](../../schema/v0.4.0/rule-result.schema.json) and [Assessment Result schema](../../schema/v0.4.0/assessment-result.schema.json) require a nonblank `summary` explaining the outcome; this is a **pre-alpha schema contract**, not proof of scanner execution. **Draft — Needs Review:** reconcile older `message` prose and settle canonical-result projection behavior in the [Results specification](../../specification/results/results.md).

## 6. Validate, compile, then distribute

1. Use a single versioned authoring format. The current review set supplies equivalent YAML and JSON.
2. Check syntax and the applicable JSON Schema; then check references and semantic constraints. **Schema validity alone does not establish semantic or scanner conformance.**
3. Compile resolved authoring content into self-contained, scanner-facing content. Compiled logical references must not depend on original authoring paths.
4. Keep source/conversion evidence distinct from executable content, and do not describe an unsigned or unexecuted package as a verified scanner result.

See [conformance layers](../../specification/core/conformance.md), [packaging and integrity](../../specification/package/package-and-integrity.md), and the [current compilation limitations](../developer/CONVERTER-COMPILER-RUNBOOK.md).

## 7. Before publishing

- Confirm exact SCAP-NG version, source identity, references, and Assessment choices.
- Confirm that Items, fields, expected values, and logical composition express the intended requirement.
- Preserve publisher identifiers and distinguish observed facts from policy values.
- Cite the governing normative sections and record unproved behavior for review.

### Appendix: migration terminology

SCAP-NG does not require prior OVAL knowledge. For migration, use the [SCAP 1.4 concept crosswalk](../../specification/crosswalk/scap-1.4-concept-crosswalk.md) and [OVAL 5.12.3 mapping](../../specification/migration/oval-5.12.3-to-ng.md). Legacy behavior must be checked against pinned upstream XSDs and annotations, [NIST SP 800-126 Rev. 4](https://csrc.nist.gov/pubs/sp/800/126/r4/final), its [800-126A Rev. 4 annex](https://csrc.nist.gov/pubs/sp/800/126/a/r4/final), [NIST IR 7275 Rev. 4 (XCCDF 1.2)](https://csrc.nist.gov/pubs/ir/7275/r4/upd1/final), and applicable Schematron/normative prose. Legacy XML structure alone does not define native NG semantics.
