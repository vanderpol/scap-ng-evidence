# SCAP-NG 0.4 normalized library review candidate (#261)

This is an out-of-place layout preview, not a final 0.4 release or a new
semantic-verification result. Native YAML is under content/. Generated catalog
and SQLite metadata support lazy navigation; records/ preserves the exact
original Rule ledgers and source traces. Native compiler input remains logical
IDs in the existing local/global visibility model. Profiles stay embedded.

65 original streams /8,892 Rules: 4,258 retained static proofs +2,559 unverified
native +422 blocked automated +1,653 manual/OCIL records. All 6,817 compiled
Assessment program hashes and all 4,258 accepted proof triples are unchanged.
All 13,754 native YAML files are byte-identical to the original DRAFT. There
are 60 native Benchmarks, 60 applicability registries, 6,817 Rules and 6,817
Assessments. Five streams lacking native candidates remain original-only
records with publisher titles; no fake native Benchmarks/Assessments are added.

Use the exact source toolchain linked by the parent evidence manifest:

python tools/scap_ng_library_cli.py check /path/to/this/content
python tools/scap_ng_library_cli.py search /path/to/this/content --kind assessment --status CONVERTED_UNVERIFIED
python tools/scap_ng_library_cli.py records /path/to/this/content --status MANUAL_OCIL_ONLY_PRESERVED
python tools/scap_ng_library_cli.py analyze /path/to/this/content

The SQLite cache is disposable; an explicit index rebuild restores proof/
warning associations from durable records and rechecks current hashes. Do not
delete the original records/provenance. Standalone Assessments need no Benchmark
or catalog. Analyze/check never rewrite source. Apply is explicit, diff-first,
presentation-only and guarded; no-op saves remain byte-identical. No automatic
cross-Assessment deduplication or consumer repointing occurs. Reuse proposals
are published separately; titles/fingerprints are never semantic-proof authority.

Original signed ZIP/XML/manual content remains in the immutable complete DRAFT:
https://github.com/vanderpol/scap-ng-evidence/tree/v04-revised-all65-draft-files-20261030-a08c9beb9/runs/v04-converter/2026-10-30-all-65-revised-draft-download
SHA256 a09ee9a13cdfeeb1b8599eab61308e935a19b99eb62eadafd32002d13d90f8bd

Offline native editing/indexing/compilation does not contact that repository.
Original XML inspection needs the separately downloaded source artifact. Exact
per-Rule archive members and source identities remain in records. Runtime
scanner equivalence, full original policy/applicability/manual migration,
publisher authentication and new independent source proofs are not claimed.
Licensing status is unchanged; no new project-wide license grant is made.
