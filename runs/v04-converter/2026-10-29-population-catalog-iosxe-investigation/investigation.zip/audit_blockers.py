"""Read-only original binding/population investigation; no conversion or repair."""
from collections import Counter
from pathlib import Path
import json,sys,zipfile
sys.path.insert(0,'/workspace/scap-ng/tools')
from v04_direct_scap_source import SourceModel,OVAL,digest,xml_identity,XLINK

ROOT=Path(__file__).parent
pins={p['file']:p for p in json.loads((ROOT/'source-pins.json').read_text())['sources']}
with zipfile.ZipFile('/workspace/scap-ng-evidence/runs/v04-converter/2026-10-28-niwc-65-draft-248895772/niwc-65-draft-248895772.zip') as z:
    rows=json.loads(z.read('ledger.json'))['rules']
catalog=[];populations=[]
for file,pin in pins.items():
    selected=[r for r in rows if r['benchmark']+'.zip'==file and r.get('primary_blocker',{}).get('message','').startswith(('unresolved checklist catalog href:','unsupported Test existence: all_exist'))]
    if not selected:continue
    source=SourceModel(ROOT/'inputs'/file,pin['sha256'],inventory_broken_references=True)
    blocked=[r for r in selected if r['primary_blocker']['message'].startswith('unresolved checklist')]
    if blocked:
        details=[]
        for row in blocked:
            refs={(ref['href'],ref['name']) for check in row['checks'] if check['system']==OVAL for ref in check['references'] if ref.get('href') not in source.catalog}
            for href,identifier in sorted(refs):
                candidates=[c for c,index in source.nodes.items() if identifier in index and index[identifier].tag=='{'+OVAL+'}definition']
                entries=[u for u in source.checklist.iter() if u.tag.endswith('}uri') and u.get('name')==href]
                chains=[]
                for u in entries:
                    ref=source.references.get(u.get('uri','').removeprefix('#'))
                    component=ref.get(XLINK,'').removeprefix('#') if ref is not None else None
                    chains.append({'entry_tag':u.tag,'uri':u.get('uri'),'component':component,
                                   'target_definition_present':component in candidates})
                details.append({'rule':row['source_rule'],'href':href,'definition':identifier,
                    'named_catalog_entry_present':any(u.tag=='{urn:oasis:names:tc:entity:xmlns:xml:catalog}uri' for u in entries),
                    'unrecognized_entries':chains,
                    'embedded_definition_components':candidates,'binding_recovered':False})
        catalog.append({'source_pin':pin,'affected_rules':len(blocked),'catalog':source.catalog,'catalog_errors':source.catalog_errors,
                        'classification':'original_packaging_deficiency','references':details})
    for row in selected:
        if row['primary_blocker']['message']!='unsupported Test existence: all_exist':continue
        tests=[]
        dynamic=any(d['kind']=='variable' for d in row['dependencies'])
        for dep in row['dependencies']:
            if dep['kind']!='test':continue
            test=source.node(dep['component'],dep['id'],'test')
            if test.get('check_existence')!='all_exist':continue
            objref=next(c.get('object_ref') for c in test if c.tag.endswith('}object'))
            obj=source.node(dep['component'],objref,'object')
            tests.append({'test':dep['id'],'component':dep['component'],'source_check_existence':'all_exist',
                'test_sha256':digest(xml_identity(test)),'object':objref,'object_sha256':digest(xml_identity(obj)),
                'state_bearing':any(c.tag.endswith('}state') for c in test),
                'object_has_variable_binding':any(n.get('var_ref') or n.tag.endswith('}object_component') or n.tag.endswith('}var_ref') for n in obj.iter()),
                'object_has_set_or_filter':any(n.tag.endswith(('}set','}filter')) for n in obj.iter()),
                'capability':dep['capability']})
        populations.append({'file':file,'source_zip_sha256':pin['sha256'],'rule':row['source_rule'],
                            'closure_has_variables':dynamic,'tests':tests})
summary={'catalog_rules':sum(r['affected_rules'] for r in catalog),'catalog_sources':len(catalog),
         'catalog_reference_counts':dict(Counter('embedded_definition_available_but_unbound' if r['embedded_definition_components'] else 'referenced_definition_missing' for s in catalog for r in s['references'])),
         'catalog_wrong_namespace_with_complete_chain':sum(len(r['unrecognized_entries'])==1 and r['unrecognized_entries'][0]['entry_tag']=='{http://scap.nist.gov/schema/scap/source/1.2}uri' and r['unrecognized_entries'][0]['target_definition_present'] for s in catalog for r in s['references']),
         'all_exist_primary_rules':len(populations),'all_exist_rules_with_state':sum(any(t['state_bearing'] for t in r['tests']) for r in populations),
         'all_exist_rules_with_variable_closure':sum(r['closure_has_variables'] for r in populations),
         'all_exist_rules_with_set_or_filter':sum(any(t['object_has_set_or_filter'] for t in r['tests']) for r in populations),
         'runtime_evidence':False,'source_repair':False,'native_admission_changed':False}
(ROOT/'blocker-audit.json').write_text(json.dumps({'summary':summary,'catalog':catalog,'all_exist':populations},indent=2)+'\n')
print(json.dumps(summary,indent=2))
