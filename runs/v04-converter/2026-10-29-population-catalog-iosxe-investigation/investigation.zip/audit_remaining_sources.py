"""Validate 39 explicitly blocked original closures; no conversion or repair."""
import json,sys,zipfile
from pathlib import Path
from collections import Counter,defaultdict
from lxml import etree as E
sys.path.insert(0,'/workspace/scap-ng/tools')
from v04_direct_scap_source import OVAL
from oval_source_validation import SourceValidator
from inventory_v04_six_source_requirements import closure_validity

root=Path(__file__).parent
groups=defaultdict(list)
for path in (root/'all-65-draft').glob('*/ledger.json'):
    for row in json.loads(path.read_text())['rules']:
        if row['draft_status']!='BLOCKED_EXPLICIT':continue
        issue=row['primary_blocker'];m=issue['message']
        if issue['category']=='source-exclusion' or m.startswith(('unresolved checklist catalog href:','unsupported Test existence:','unsupported function:')) or m in ['OVAL check imports/exports unsupported','multiple aggregation components need an approved collection expression','unsupported acquisition parameter comparison/type']:continue
        groups[path.parent.name+'.zip'].append(row)
validator=SourceValidator('/workspace/scap-ng/third_party/scap-1.4-schemas/oval_5.12.3')
results=[]
for file,rows in sorted(groups.items()):
    with zipfile.ZipFile(root/'inputs'/file) as z:
        original=E.fromstring(z.read(next(n for n in z.namelist() if n.endswith('.xml'))))
    checks={c.get('id'):validator.validate(c[0]) for c in original.findall('{http://scap.nist.gov/schema/scap/source/1.2}component') if c[0].tag=='{'+OVAL+'}oval_definitions'}
    for row in rows:
        validity=closure_validity(row['dependencies'],checks)
        results.append({'file':file,'rule':row['source_rule'],'source_rule_sha256':row['source_rule_sha256'],
                        'primary_blocker':row['primary_blocker'],'source_validity':validity,'admitted':False})
    print(file,dict(Counter(r['source_validity']['status'] for r in results if r['file']==file)),flush=True)
assert len(results)==39,len(results)
(root/'remaining-39-source-validity.json').write_text(json.dumps({'cases':results,'summary':dict(Counter(r['source_validity']['status'] for r in results)),'source_repair':False,'native_conversion_attempted':False},indent=2)+'\n')
