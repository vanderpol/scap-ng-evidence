"""Pinned OVAL reference cases; does not model or claim a native scanner."""
import json,sys
from hashlib import sha256
from pathlib import Path
sys.path.insert(0,'/workspace/scap-ng/tools')
from oval_result_truth_tables import evaluate_collected_object_test

root=Path(__file__).parent
cases=[
 ('complete-zero',dict(flag='complete',exists=0),('false','false')),
 ('complete-one',dict(flag='complete',exists=1),('true','true')),
 ('complete-many',dict(flag='complete',exists=3),('true','true')),
 ('expected-population-partly-absent',dict(flag='complete',exists=1,does_not_exist=1),('false','true')),
 ('material-item-error',dict(flag='complete',exists=1,error=1),('error','true')),
 ('material-item-unknown',dict(flag='complete',exists=1,not_collected=1),('unknown','true')),
 ('collection-error',dict(flag='error',exists=1),('error','error')),
 ('collection-unknown',dict(flag='not collected',exists=1),('unknown','unknown')),
 ('incomplete-zero',dict(flag='incomplete',exists=0),('unknown','unknown')),
 ('incomplete-state-free-positive',dict(flag='incomplete',exists=1),('unknown','unknown')),
 ('incomplete-stateful-positive-any-match',dict(flag='incomplete',exists=1,has_state=True,check='at least one',item_results=['true']),('unknown','true')),
]
results=[]
for name,kw,expected in cases:
    args={'has_state':False,**kw}
    actual=tuple(evaluate_collected_object_test(existence=m,**args) for m in ['all_exist','at_least_one_exists'])
    assert actual==expected,(name,actual,expected)
    results.append({'case':name,'oval_evidence':args,'oval_all_exist':actual[0],
                    'oval_at_least_one_exists':actual[1],'native_scanner_result':'NOT_RUN'})
schema=Path('/workspace/scap-ng/third_party/scap-1.4-schemas/oval_5.12.3/oval-common-schema.xsd')
text=schema.read_text()
assert "this value is equivalent to 'at_least_one_exists'" in text
assert '||  0+  |  1+  |  0+  |  0+  ||  False' in text
(root/'population-cases.json').write_text(json.dumps({'reference_schema_sha256':sha256(schema.read_bytes()).hexdigest(),
    'cases':results,'result':'11 independent expected boundary vectors reproduced by existing OVAL reference helper',
    'limitation':'Neither native result semantics nor live scanner execution established'},indent=2)+'\n')
print('11 source-chart boundary cases pass; native runtime not run')
