# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"BLOCKED": 117, "MANUAL_OCIL_ONLY": 40, "PROVED": 291}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_mil.disa.stig_rule_SV-271431r1092616_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271432r1091008_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271433r1091011_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271434r1091014_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271435r1091017_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271436r1091020_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271437r1091023_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271438r1155341_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271439r1091029_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271440r1092462_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271441r1137691_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271442r1137691_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271443r1092463_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271444r1091044_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271445r1091047_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271446r1155293_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271447r1155295_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271448r1155297_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271449r1091059_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271450r1092466_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271451r1137691_rule | BLOCKED | original OVAL closure invalid/deprecated |
| xccdf_mil.disa.stig_rule_SV-271452r1091068_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271453r1091071_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271454r1092458_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271455r1091077_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271456r1091080_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271457r1208721_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271458r1091086_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271459r1184166_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271460r1091092_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271461r1091095_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271462r1184169_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271463r1184172_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271465r1091107_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271466r1091110_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271467r1091113_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271468r1091116_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271469r1091119_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271470r1092618_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271471r1091125_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271472r1091128_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271473r1091131_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271474r1091134_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271475r1091137_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271476r1091140_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271477r1190784_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271478r1190787_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271479r1184180_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271480r1091152_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271482r1091158_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271483r1091161_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271485r1184186_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271486r1184188_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271487r1091173_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271488r1091176_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271489r1184190_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271490r1184192_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271491r1091185_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271493r1091191_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271494r1091194_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271495r1091197_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271496r1091200_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271497r1092471_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271498r1091206_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271499r1091209_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271500r1091212_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271501r1091215_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271502r1091218_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271503r1091221_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271504r1091224_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271506r1091230_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271507r1091233_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271508r1091236_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271509r1091239_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271510r1091242_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271511r1091245_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271512r1091248_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271513r1091251_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271514r1091254_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271515r1091257_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271516r1208722_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271517r1101885_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271518r1091266_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271519r1091269_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271520r1091272_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271521r1091275_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271522r1091278_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271523r1091281_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271524r1091284_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271525r1091287_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271526r1092460_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271527r1092474_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271528r1092476_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271529r1092478_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271530r1092480_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271531r1092482_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271532r1092484_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271533r1092486_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271534r1092488_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271535r1092490_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271536r1092492_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271537r1092494_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271538r1092496_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271539r1092498_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271540r1092500_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271541r1092502_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271542r1092504_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271543r1092506_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271544r1092508_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271545r1092510_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271546r1092512_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271547r1092514_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271548r1092516_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271549r1092518_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271550r1092520_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271551r1092522_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271552r1092524_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271553r1092526_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271554r1092528_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271555r1092530_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271556r1092532_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271557r1092534_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271558r1092536_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271559r1092538_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271560r1092540_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271561r1092542_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271562r1092544_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271563r1092546_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271564r1092548_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271565r1092550_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271566r1092552_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271567r1092554_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271568r1092556_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271569r1155308_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271570r1092558_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271571r1092560_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271572r1092562_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271573r1092564_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271574r1092566_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271575r1092568_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271576r1092570_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271577r1091443_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271578r1092572_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271579r1091449_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271580r1091452_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271581r1091455_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271582r1092574_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271583r1091461_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271584r1091464_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271585r1091467_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271586r1092576_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271587r1208723_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271588r1091476_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271589r1091479_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271590r1091482_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271591r1092578_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271592r1091488_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271593r1092580_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271594r1208724_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271595r1155316_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271596r1091500_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271597r1092586_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271598r1092588_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271599r1134856_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271600r1134858_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271601r1091515_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271602r1092590_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271603r1092592_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271604r1091524_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271605r1091527_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271606r1091530_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271607r1091533_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271608r1091536_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271609r1091539_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271610r1091542_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271611r1091545_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271612r1091548_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271613r1091551_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271614r1091554_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271615r1091557_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271616r1091560_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271617r1091563_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271618r1091566_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271619r1091569_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271620r1091572_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271621r1091575_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271622r1091578_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271623r1091581_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271624r1091584_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271625r1091587_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271626r1091590_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271627r1091593_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271628r1208725_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271629r1091599_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271630r1091602_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271631r1091605_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271632r1091608_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271633r1091611_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271634r1091614_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271635r1137691_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271636r1091620_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271637r1091623_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271638r1091626_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271639r1091629_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271641r1091635_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271642r1092593_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271643r1091641_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271644r1091644_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271645r1091647_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271646r1091650_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271647r1091653_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271648r1091656_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271649r1208728_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271650r1091662_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271651r1091665_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271652r1094966_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271653r1091671_rule | BLOCKED | unsupported function: split |
| xccdf_mil.disa.stig_rule_SV-271654r1091674_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271655r1091677_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271656r1091680_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271657r1091683_rule | BLOCKED | unsupported function: split |
| xccdf_mil.disa.stig_rule_SV-271658r1091686_rule | BLOCKED | unsupported function: split |
| xccdf_mil.disa.stig_rule_SV-271659r1091689_rule | BLOCKED | unsupported function: split |
| xccdf_mil.disa.stig_rule_SV-271660r1091692_rule | BLOCKED | unsupported function: split |
| xccdf_mil.disa.stig_rule_SV-271661r1091695_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271662r1091698_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271663r1091701_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271664r1091704_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271665r1091707_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271666r1091710_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271667r1091713_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271668r1091716_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271669r1184200_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271670r1091722_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271671r1091725_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271672r1092631_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271673r1091731_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271674r1208729_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271676r1091740_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271677r1091743_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271678r1091746_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271679r1091749_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271680r1091752_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271681r1091755_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271682r1091758_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271683r1091761_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271684r1091764_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271685r1091767_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271686r1091770_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271687r1091773_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271688r1091776_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271689r1091779_rule | BLOCKED | original OVAL closure invalid/deprecated |
| xccdf_mil.disa.stig_rule_SV-271690r1092634_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271691r1091785_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271692r1091788_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271693r1091791_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271694r1091794_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271695r1091797_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271696r1091800_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271697r1184202_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271698r1091806_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271699r1091809_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271700r1091812_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271701r1091815_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271703r1091821_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271704r1091824_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271705r1091827_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271706r1091830_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271707r1091833_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271708r1092594_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271709r1091839_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271710r1092596_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271711r1091845_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271712r1091848_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271713r1091851_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271714r1091854_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271715r1091857_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271716r1091860_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271718r1091866_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271719r1091869_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271720r1091872_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271721r1091875_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271722r1091878_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271723r1091881_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271724r1091884_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271725r1155318_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271726r1091890_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271727r1091893_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271728r1091896_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271729r1155325_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271730r1155327_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271731r1155302_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271732r1155329_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271733r1092598_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271734r1091914_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271735r1091917_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271736r1091920_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271737r1094967_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271738r1092600_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271739r1091929_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271740r1091932_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271741r1091935_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271742r1091938_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271743r1184204_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271744r1091944_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271745r1198253_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271746r1198253_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271747r1198253_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271748r1198253_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271749r1198253_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271750r1091962_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271751r1184206_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271752r1091968_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271753r1091971_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271754r1184208_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271755r1091977_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271756r1091980_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271757r1092604_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271758r1091986_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271759r1184210_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271760r1091992_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271761r1208732_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271763r1092001_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271764r1092004_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271766r1092010_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271768r1092016_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271769r1092019_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271770r1092022_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271771r1208733_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271772r1092028_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271773r1155299_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271774r1092034_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271775r1092037_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271776r1092040_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271777r1092043_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271778r1092046_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271779r1137695_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271780r1092052_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271781r1092055_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271782r1184213_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271783r1184216_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271784r1184219_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271785r1155290_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271786r1092070_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271787r1092073_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271788r1155305_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271789r1134863_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271790r1134866_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271791r1134971_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271792r1094968_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271793r1092605_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271794r1092094_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271795r1092097_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271796r1092100_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271797r1092103_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271798r1092106_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271799r1092109_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271800r1092112_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271801r1092115_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271802r1092118_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271803r1092121_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271804r1092124_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271805r1092127_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271806r1092130_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271807r1092133_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271808r1092136_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271809r1092139_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271810r1092142_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271811r1092145_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271812r1092148_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271813r1092151_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271814r1092154_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271815r1092157_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271816r1092160_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271817r1092163_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271818r1092166_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271819r1092169_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271820r1092172_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271821r1092175_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271822r1092178_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271823r1092181_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271824r1092184_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271825r1092187_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271826r1092190_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271827r1092193_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271828r1092196_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271829r1092199_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271830r1092202_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271831r1092205_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271832r1092208_rule | BLOCKED | unsupported function: count |
| xccdf_mil.disa.stig_rule_SV-271833r1092607_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271834r1208734_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271835r1092217_rule | BLOCKED | unsupported function: count |
| xccdf_mil.disa.stig_rule_SV-271836r1092637_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271837r1092223_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271838r1092226_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271839r1092229_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271840r1092232_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271841r1092235_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271842r1092238_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271843r1094969_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271844r1184222_rule | BLOCKED | comparator-bearing absence blocked |
| xccdf_mil.disa.stig_rule_SV-271845r1092247_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271846r1092250_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271847r1092253_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271848r1184224_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271849r1092259_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271850r1092262_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271851r1092265_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271852r1184227_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271853r1092271_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271854r1092274_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271855r1092277_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271856r1092280_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271857r1184229_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271858r1092286_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271859r1092289_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271860r1092292_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271861r1092295_rule | BLOCKED | unsupported function: count |
| xccdf_mil.disa.stig_rule_SV-271862r1092298_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271863r1092639_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-271864r1092304_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271865r1092307_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271866r1092310_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271867r1092313_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271868r1172845_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271869r1092319_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271870r1092322_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271871r1172843_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271872r1092328_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271873r1092331_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271874r1092612_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271875r1092337_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271876r1092641_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271877r1092343_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271878r1092346_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271879r1092349_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271880r1092352_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271881r1092355_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271882r1092358_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271883r1092361_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271884r1208735_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-271885r1092367_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271886r1092370_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-271901r1092415_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-278952r1135407_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-279935r1156358_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-284946r1208737_rule | PROVED | [] |
