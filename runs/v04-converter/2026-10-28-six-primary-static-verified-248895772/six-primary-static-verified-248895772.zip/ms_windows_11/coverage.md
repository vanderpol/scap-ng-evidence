# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"BLOCKED": 18, "MANUAL_OCIL_ONLY": 11, "PROVED": 228}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_mil.disa.stig_rule_SV-253254r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253255r1210279_rule | BLOCKED | original OVAL closure invalid/deprecated |
| xccdf_mil.disa.stig_rule_SV-253256r1210280_rule | BLOCKED | original OVAL closure invalid/deprecated |
| xccdf_mil.disa.stig_rule_SV-253257r1210281_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253259r1210282_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253260r1210283_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253261r1210284_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253262r958808_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-253263r1016364_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253264r1186372_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253265r1137691_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253266r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253267r1137695_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-253268r1051039_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-253269r958702_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-253270r991589_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-253271r958702_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-253272r1210286_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-253273r1051040_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253274r1016661_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253275r958478_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253276r958480_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253277r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253278r958480_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253279r958480_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253280r991589_rule | BLOCKED | original OVAL closure invalid/deprecated |
| xccdf_mil.disa.stig_rule_SV-253281r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253282r991593_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-253284r958928_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253285r1153425_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253286r958478_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253287r958478_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253288r958478_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253289r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253290r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253291r1153422_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253293r991589_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253294r991589_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-253296r1256651_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253297r958736_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253298r958388_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253299r958388_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253300r1256653_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253301r1051042_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253302r1051043_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253303r1051044_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253304r1051045_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253305r1051046_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253306r991570_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253307r991570_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253308r971541_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253309r958566_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253310r991551_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253311r1051047_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253312r1051048_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253313r991578_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253314r991570_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253315r958406_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253316r991581_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253317r991581_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253318r991578_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253319r991572_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253320r991572_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253321r991572_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253322r991572_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253323r991583_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253324r991583_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253325r991572_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253326r991572_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253327r991572_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253328r958732_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253329r991575_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253330r991586_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253331r991579_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253332r991579_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253333r991575_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253334r991575_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253335r991573_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253336r991573_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253337r958752_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253338r1186375_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253339r958752_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253340r958434_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253341r958434_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253342r958434_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253344r958412_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253345r958412_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253346r958412_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253347r958412_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253348r958412_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253349r958412_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253350r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253351r1106508_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-253352r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253353r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253354r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253355r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253356r958902_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253357r958518_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253358r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253359r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253360r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253361r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253362r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253363r971535_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253364r958358_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253365r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253367r958422_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253368r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253369r1210289_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253370r1210290_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253371r1210291_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253372r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253373r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253374r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253375r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253376r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253377r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253378r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253379r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253380r1051049_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253381r1051050_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253382r1137695_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253383r971545_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253384r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253385r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253386r958804_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253387r958804_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253388r958804_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253389r1256673_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253391r958518_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253392r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253393r1256676_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253394r1256679_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253395r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253396r958928_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253397r958902_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253398r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253399r1256682_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253400r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253401r1210296_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253402r1051051_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253403r1137695_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253404r1051052_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253405r991554_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253406r958408_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253407r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253408r958478_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253409r1210297_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253410r1051053_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253411r1051054_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253412r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253413r991591_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253414r958422_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253415r958420_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253416r958510_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253417r958848_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253418r958510_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253419r958850_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253420r1051055_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253421r958510_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253422r1256685_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253423r958478_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253424r1210299_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253425r958478_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253426r991580_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253427r1256656_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253428r1256659_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253429r1256662_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253430r1256665_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253431r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253433r958504_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253434r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253435r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253436r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253437r958442_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253438r958908_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253439r958908_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253440r958908_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253441r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253442r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253443r958908_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253444r958636_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253445r1210302_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253446r958586_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253447r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253448r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253449r958908_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253450r987796_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253451r958908_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253452r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253453r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253454r1137695_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253455r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253456r1137695_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253457r1081060_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253458r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253459r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253460r971535_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253461r1051056_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253462r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253463r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253464r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253465r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253466r1210303_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253467r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253468r1051057_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253469r958518_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253470r1256666_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253471r1051058_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253472r958518_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253473r958518_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253474r1051059_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253475r958518_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253476r1210304_rule | BLOCKED | original OVAL closure invalid/deprecated |
| xccdf_mil.disa.stig_rule_SV-253477r958478_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-253478r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253479r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253480r1137691_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253481r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253482r1137691_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253483r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253484r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253485r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253486r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253487r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253488r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253489r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253490r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253491r1137691_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253492r1137691_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253493r1137691_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253494r1137691_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253495r1137691_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253496r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253497r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253498r1138526_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253499r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253500r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253501r958434_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253502r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253503r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253504r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253505r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-253506r958726_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-256893r958552_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257592r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257770r958412_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-268317r1135320_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-268318r1210288_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278928r1135302_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278930r1135308_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278931r1135311_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278932r1141916_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278933r1141919_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-279688r1256671_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-288475r1256669_rule | MANUAL_OCIL_ONLY | [] |
