# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"BLOCKED": 114, "MANUAL_OCIL_ONLY": 27, "PROVED": 304}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_mil.disa.stig_rule_SV-257777r1155676_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257778r1134892_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-257779r958390_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257781r991589_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257782r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257783r991562_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257784r1208766_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257785r1044833_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257786r1044834_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257787r1184288_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257788r1044838_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257789r1137691_rule | BLOCKED | original OVAL closure invalid/deprecated |
| xccdf_mil.disa.stig_rule_SV-257790r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257791r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257792r1184289_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257793r1044843_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257794r1069362_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257795r1044845_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257796r1044847_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257797r1198253_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257798r1198253_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257799r1155697_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257800r1198253_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257801r1155703_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257802r1155706_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257803r1155668_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257804r1044853_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257805r1044856_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257806r1044859_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257807r1044862_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257808r1044865_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257809r1208769_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257810r1198253_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257811r1198253_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257812r1134897_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257813r1134899_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257814r1156057_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257815r1134903_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257816r1155715_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257817r1069383_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257818r1044876_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257819r1015075_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257820r1044878_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257821r1015077_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257822r1155615_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257823r1155641_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257824r1044886_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257825r1184291_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257826r1208770_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257827r1044892_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257828r1044894_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257829r1044896_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257830r1134906_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257831r1044898_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257832r1155653_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257833r1044902_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257834r1044904_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257835r1155679_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257836r1044908_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257837r1044910_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257838r1044912_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257839r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257840r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257841r1044914_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257842r1044916_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257843r991589_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257844r1044918_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257845r1044920_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257846r1044922_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257847r1044924_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257848r1044926_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257849r1044928_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257850r1044930_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257851r1044932_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257852r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257854r1044934_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257855r1044936_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257856r1044938_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257857r991589_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-257858r991589_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-257859r991589_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-257860r1044940_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257861r1044941_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257862r1184295_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257863r1155633_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257864r1155639_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257865r1184297_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257866r958804_rule | BLOCKED | unsupported function: split |
| xccdf_mil.disa.stig_rule_SV-257867r958804_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257868r958804_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257869r1102009_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257870r958804_rule | BLOCKED | unsupported function: split |
| xccdf_mil.disa.stig_rule_SV-257871r958804_rule | BLOCKED | unsupported function: split |
| xccdf_mil.disa.stig_rule_SV-257872r958804_rule | BLOCKED | unsupported function: split |
| xccdf_mil.disa.stig_rule_SV-257873r958804_rule | BLOCKED | unsupported function: split |
| xccdf_mil.disa.stig_rule_SV-257874r958804_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257875r958804_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257876r958804_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257877r958804_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257878r958804_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257879r1045454_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-257880r1044951_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257881r1184299_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257882r991560_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257883r991560_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257884r1106306_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257885r1044953_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257886r1044955_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257887r991557_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257888r1208771_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257889r1184302_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257890r1184305_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257891r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257892r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257893r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257894r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257895r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257896r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257897r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257898r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257899r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257900r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257901r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257902r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257903r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257904r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257905r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257906r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257907r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257908r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257909r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257910r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257911r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257912r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257913r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257914r1044969_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257915r1044971_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257916r1101916_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257917r1101914_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257918r1044977_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257919r1044979_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257920r1101926_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257921r1106308_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257922r1044988_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257923r1044991_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257924r991557_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257925r991557_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257926r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257927r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257928r1155576_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-257929r1137695_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257930r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257931r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257932r1014838_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-257934r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257935r1044994_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257936r1044995_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257937r1106310_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-257939r1044997_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257940r1106312_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-257941r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257942r1155718_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257943r1045001_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257944r1038944_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257945r1038944_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-257946r1184307_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257947r958480_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257948r1045004_rule | BLOCKED | unsupported function: count |
| xccdf_mil.disa.stig_rule_SV-257949r1134947_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257950r1045006_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-257951r1014843_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257953r958424_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257954r1106315_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257955r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257956r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257957r1155618_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257958r1155721_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257959r1155724_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257960r1155727_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257961r1155730_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257962r1155733_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257963r1155736_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257964r1155739_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257965r1155646_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257966r1155742_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257967r1155745_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257968r1155748_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257969r1155623_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257970r1155751_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257971r1155754_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257972r1155757_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257973r1155760_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257974r1155763_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257975r1155766_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257976r1155769_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257977r1155772_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257978r1045013_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257979r958908_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257980r1045016_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257981r1101970_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257982r1045021_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257983r1045024_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257984r1045026_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257985r1069364_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257986r1045030_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257989r1184309_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257991r1184311_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257992r1045047_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257993r1045049_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257994r1045051_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-257995r1045053_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257996r1134915_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257997r1069370_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257998r1082181_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-257999r1155686_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258000r1208772_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258001r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258003r1045065_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258004r1045067_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258005r1045069_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258006r1045071_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258007r1045073_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258008r1045075_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258009r1045077_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258011r1045079_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258012r1014855_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258013r1045082_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258014r1045084_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258015r1045086_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258016r958804_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258017r1155688_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258018r1045090_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258019r1045092_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258020r1045094_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258021r1015088_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258022r1045097_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258023r1155656_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258024r1045100_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258025r958402_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258026r1045103_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258027r1045106_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258028r991589_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258029r1045109_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258030r1045112_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258031r1134920_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258032r1045117_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258033r1045120_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258034r1051267_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258035r1045125_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258036r1014861_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258037r1014863_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258038r1045128_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258039r1045131_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258040r991568_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258041r1038967_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258042r1045133_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258043r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258044r1184313_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258045r958482_rule | BLOCKED | unsupported function: count |
| xccdf_mil.disa.stig_rule_SV-258046r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258047r1101951_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258048r1069380_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258049r1015092_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258050r1045137_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258051r991589_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258052r1184315_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258053r1208773_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258054r958736_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258055r1045140_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258056r1045143_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258057r1045146_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258058r1045148_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258059r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258060r1045150_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258061r958482_rule | BLOCKED | unsupported function: count |
| xccdf_mil.disa.stig_rule_SV-258068r1101950_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258069r958398_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258070r1045153_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258071r991588_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258072r1184320_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258073r1184322_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258074r991590_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258075r1184324_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258077r1155659_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258078r958944_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258079r1045159_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258080r1045162_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258081r1045164_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258082r1045166_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258083r1045168_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258084r1050789_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258085r1045173_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258086r1102063_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258087r1102071_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258088r1155643_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258089r1045179_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258090r958808_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258091r1208774_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258094r1045187_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258095r1045189_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258096r1045191_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258097r1045193_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258098r1045195_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258099r1045198_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258100r1045201_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258101r1045204_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258102r1045207_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258103r1045210_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258104r1015104_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258105r1045212_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258106r1102061_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258107r1045218_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258109r1045220_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258110r1045223_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258111r1045226_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258112r1045229_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258113r1045232_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258114r1045235_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258115r1045238_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258116r1045240_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258117r1015116_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258118r1050789_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258120r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258121r1155682_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258122r1045246_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258123r1134923_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258124r1045250_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258125r1208775_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258126r1045255_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258127r1155648_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258128r1155626_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258129r1155628_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258131r1134927_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258132r1134929_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258133r1045263_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258134r1155620_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258135r1045267_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258136r1045270_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258137r1102081_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258138r1045274_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258139r1045276_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258140r1106460_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258141r1045280_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258142r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258143r1184329_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258144r1045286_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258146r1045288_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258147r1045290_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258148r1045292_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258149r1155580_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258150r1045296_rule | MANUAL_OCIL_ONLY | [] |
| xccdf_mil.disa.stig_rule_SV-258151r1045298_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258152r1015127_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258153r1038966_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258154r1038966_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258155r1045300_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258156r1106364_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258157r1134932_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258158r971542_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258159r971542_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258160r1038966_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258161r958416_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258162r1184331_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258163r958424_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258164r1045301_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258165r958434_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258166r1045303_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258167r1155630_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258168r958428_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258169r991556_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258170r991589_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258171r1208777_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258173r1101933_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258174r958424_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258175r1045310_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258176r1155595_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258177r1155597_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258178r1155599_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258179r1155601_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258180r1045325_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258181r1045328_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258182r1045331_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258183r1045334_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258184r1045337_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258185r1045340_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258186r1045343_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258187r1155603_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258188r1155605_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258189r1155607_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258190r1155609_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258191r1045358_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258192r1045361_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258193r1045364_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258194r1045367_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258195r1045370_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258196r1045373_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258197r1045376_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258198r1045379_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258199r1045382_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258200r1045385_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258201r1045388_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258202r1045391_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258203r1045394_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258204r1045397_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258205r1045400_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258206r1045403_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258207r1045406_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258208r1045409_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258209r1045412_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258210r1045415_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258211r1045418_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258212r1045421_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258213r1045424_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258214r1045427_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258215r1155611_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258216r1155613_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258217r1210919_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258218r1210920_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258219r1210921_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258220r1210922_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258221r1210923_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258222r1210924_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258223r1210925_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258224r1210926_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258225r1210927_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258227r1014992_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258228r991572_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258229r958434_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258230r1184334_rule | BLOCKED | unsupported Test existence: all_exist |
| xccdf_mil.disa.stig_rule_SV-258231r1208790_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258232r1184335_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258233r1015136_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258234r1184292_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258236r1101920_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258241r1184293_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-258242r1184336_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-270174r1044831_rule | BLOCKED | original OVAL closure invalid/deprecated |
| xccdf_mil.disa.stig_rule_SV-270175r1137691_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-270176r1137691_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-270177r1184308_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-270178r1184310_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-270180r1184327_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-272488r1155665_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-272496r1155582_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-279936r1210929_rule | PROVED | [] |
