"""Package existing converter output as a labeled engineering draft, not proof."""
import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--toolchain', type=Path, required=True)
    parser.add_argument('--draft', type=Path, required=True)
    parser.add_argument('--evidence-id', required=True)
    args = parser.parse_args()
    tool = args.toolchain.resolve()
    output = args.draft.resolve()
    revision = subprocess.check_output(['git', '-C', str(tool), 'rev-parse', 'HEAD'], text=True).strip()
    assert revision == 'c65a134b539558609ccf3bdc0600f38e411bbb2e'
    assert not subprocess.check_output(['git', '-C', str(tool), 'status', '--porcelain', '--untracked-files=no'])
    sys.path.insert(0, str(tool / 'tools'))
    import yaml
    from v04_native_bundle_compiler import build_bundle, verify_bundle
    from audit_v04_direct_benchmark import verify_compiled

    pins = json.loads((tool / 'tests/fixtures/v04-direct-six-sources.json').read_text())
    floors = json.loads((tool / 'tests/fixtures/v04-six-primary-proof-floor.json').read_text())['sources']
    assert (output / 'invocations.json').is_file()
    all_rows, summaries, retained = [], {}, 0
    for name, pin in pins['sources'].items():
        folder = output / name
        coverage = json.loads((folder / 'coverage.json').read_text())
        trace = json.loads((folder / 'source-trace.json').read_text())
        assert coverage['source_zip_sha256'] == pin['sha256'] == floors[name]['source_sha256']
        documents = {}
        for path in sorted((folder / 'authoring').rglob('*.json')):
            document = json.loads(path.read_text())
            assert yaml.safe_load(path.with_suffix('.yaml').read_text()) == document, path
            documents[str(path.relative_to(folder))] = document
        programs = {}
        if documents:
            raw, _ = build_bundle(documents)
            result = verify_bundle(raw)
            programs = {p['assessment']: p for p in verify_compiled(documents, raw)}
            assert result['programs'] == len(programs)
            (folder / 'draft-compiled.scapng').write_bytes(raw)
            write_json(folder / 'compilation.json', {'status': 'PASS', 'toolchain_sha': revision,
                'programs': len(programs), 'compiled_operands_verified': True,
                'source_semantic_proof': 'NOT_EXECUTED_FOR_DRAFT', 'bundle_verification': result})
        else:
            write_json(folder / 'compilation.json', {'status': 'NOT_RUN_NO_CONVERTED_RULES',
                'toolchain_sha': revision, 'programs': 0})
        bindings = {r['source_rule']: r for r in trace['rules']}
        rows = []
        for original in coverage['rules']:
            row = dict(original)
            oval = any(c['system'] == 'http://oval.mitre.org/XMLSchema/oval-definitions-5' for c in row['checks'])
            ocil = bool(row['checks']) and all(c['system'] == 'http://scap.nist.gov/schema/ocil/2' for c in row['checks'])
            row.update(benchmark=name, oval_bearing=oval, scanner_evaluated=False,
                       original_source_validity='NOT_REEXECUTED_FOR_DRAFT',
                       independent_source_proof='NOT_REEXECUTED_FOR_DRAFT')
            if row['status'] == 'converted':
                binding = bindings[row['source_rule']]
                program = programs[binding['assessment']]
                row.update(draft_status='CONVERTED_COMPILED_UNPROVED',
                           native_assessment=binding['assessment'], program_sha256=program['program_sha256'],
                           compiled_operands_verified=True)
                prior = floors[name]['rules'].get(row['source_rule'])
                if prior:
                    assert prior['assessment'] == binding['assessment']
                    assert prior['program_sha256'] == program['program_sha256']
                    row['previously_proved_program_retained'] = True
                    retained += 1
            elif ocil and not oval:
                row['draft_status'] = 'OCIL_ONLY_MANUAL_UNCONVERTED'
            elif row.get('primary_blocker', {}).get('category') == 'unsupported-selection':
                row['draft_status'] = 'UNSUPPORTED_CHOICE'
            else:
                row['draft_status'] = 'BLOCKED'
            row['primary_diagnostic'] = row.get('primary_blocker')
            row['secondary_diagnostics'] = row['blockers'][1:]
            rows.append(row)
        assert len(rows) == coverage['summary']['source_rules']
        assert len({r['source_rule'] for r in rows}) == len(rows)
        assert len(bindings) == len(programs) == sum(r['status'] == 'converted' for r in rows)
        summaries[name] = {'total_rules': len(rows), 'oval_bearing': sum(r['oval_bearing'] for r in rows),
            'statuses': dict(Counter(r['draft_status'] for r in rows)), 'compiled_programs': len(programs),
            'primary_blocker_categories': dict(Counter(r['primary_diagnostic']['category']
                for r in rows if r['draft_status'] in ('BLOCKED', 'UNSUPPORTED_CHOICE')))}
        write_json(folder / 'ledger.json', {'status': 'DRAFT', 'rules': rows})
        all_rows.extend(rows)
        print(name, summaries[name], flush=True)
    assert len(all_rows) == 1567
    assert sum(r['oval_bearing'] for r in all_rows) == 1396
    assert retained == sum(len(f['rules']) for f in floors.values()) == 1055
    write_json(output / 'ledger.json', {'status': 'DRAFT', 'toolchain_sha': revision,
        'counting': 'One row per original Rule; primary statuses are disjoint; secondary blockers overlap.',
        'rules': all_rows})
    fields = ['benchmark', 'source_rule', 'title', 'draft_status', 'oval_bearing',
              'source_zip_sha256', 'source_rule_sha256', 'native_assessment', 'program_sha256',
              'primary_category', 'primary_message', 'secondary_messages']
    with (output / 'ledger.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in all_rows:
            primary = row.get('primary_diagnostic') or {}
            writer.writerow({**{k: row.get(k, '') for k in fields[:5] + fields[6:9]},
                'source_zip_sha256': row['source']['zip_sha256'],
                'primary_category': primary.get('category', ''), 'primary_message': primary.get('message', ''),
                'secondary_messages': json.dumps(row['secondary_diagnostics'], sort_keys=True)})
    metadata = {'evidence_id': args.evidence_id, 'kind': 'production-migration-engineering-draft',
        'created_at': datetime.now(timezone.utc).isoformat(), 'status': 'DRAFT_NOT_VERIFIED_RELEASE',
        'source_scap_ng_repository': 'vanderpol/scap-ng', 'toolchain_sha': revision,
        'generator': 'tools/v04_direct_converter.py --all-rules', 'input_pin': pins,
        'summaries': summaries, 'total_rules': len(all_rows), 'oval_bearing_rules': 1396,
        'converted_compiled_unproved': sum(r['status'] == 'converted' for r in all_rows),
        'previously_proved_program_hashes_retained': retained,
        'original_source_validation': 'NOT_REEXECUTED_FOR_DRAFT',
        'independent_source_proof': 'NOT_REEXECUTED_FOR_DRAFT',
        'maintained_suite': {'commit': revision, 'run': 40733597054, 'tests': 3264,
                             'failures': 0, 'errors': 0, 'skips': 1, 'status': 'PASS'},
        'raw_storage_decision': 'Owner specifically requested inspectable generated YAML/JSON and complete ledgers. Raw payload retained as evidence-repository prerelease asset, not ordinary Git history.',
        'limitations': ['Not an all-Rules lossless migration or verified release',
            'Compiled programs are not scanner-executed', 'Original manual/OCIL execution is unconverted',
            'Applicability/CPE, full policy/remediation/scoring remain unconverted',
            'Fresh exact-SHA source-proof/six-benchmark verification deferred until after draft publication',
            'Secondary blockers are currently discoverable probes, not an exhaustive proof of absence of further blockers']}
    write_json(output / 'manifest.json', metadata)
    shutil.copyfile(tool / 'tests/fixtures/v04-direct-six-sources.json', output / 'source-pins.json')
    shutil.copyfile(Path(__file__), output / 'package-six-draft.py')
    lines = ['# SCAP-NG 0.4 six-benchmark converter — DRAFT', '',
        '**Engineering preview; not a verified release, complete lossless migration, or scanner result.**', '',
        'Toolchain: `'+revision+'` (pristine detached checkout; local converter WIP excluded).',
        'NIWC source revision: `'+pins['revision']+'`; exact ZIP hashes in `source-pins.json`.', '',
        '## Contents', '', 'Open `ledger.csv` or `ledger.json` for every original Rule, including blocked/manual Rules.',
        'Each benchmark contains actual `authoring/**/*.json` and `.yaml`, `coverage.json` with',
        'primary/secondary source-node blockers, `source-trace.json`, `compilation.json`, and',
        'a `draft-compiled.scapng` only when converted content exists. Native wrappers explicitly',
        'label automated prototype subsets; applicability and full policy are unconverted.', '',
        '| Benchmark | All Rules | OVAL Rules | Compiled draft Rules | Blocked automated | OCIL-only |',
        '| --- | ---: | ---: | ---: | ---: | ---: |']
    for name, summary in summaries.items():
        counts = summary['statuses']
        lines.append(f"| {name} | {summary['total_rules']} | {summary['oval_bearing']} | {summary['compiled_programs']} | {counts.get('BLOCKED',0)+counts.get('UNSUPPORTED_CHOICE',0)} | {counts.get('OCIL_ONLY_MANUAL_UNCONVERTED',0)} |")
    lines += ['', f"All 1,567 source Rules are accounted for; 1,396 carry OVAL. {metadata['converted_compiled_unproved']} Rules compile as draft candidates.",
        'All 1,055 previously proved program hashes are retained. This retention check is not',
        'fresh independent OVAL proof. One additional authoring/compilation candidate may remain',
        'outside that proof floor and is explicitly unproved. Per-Rule statuses never infer proof',
        'from schema validation or compilation. Current draft rechecks JSON/YAML agreement,',
        'native schema/semantic compilation, compiled operands and bundle integrity.',
        'Original XSD/Schematron closure validation and independent source-term proofs have not',
        'been rerun for this draft. Exact-commit maintained CI passed separately: 3,264 run,',
        'zero failures/errors, one existing skip; https://github.com/vanderpol/scap-ng/actions/runs/40733597054 .', '',
        'DNS/Apache automated Rules currently fail strict checklist catalog resolution; their',
        'missing href/component diagnostics are retained rather than replaced with guessed aliases.',
        'Server 2025 counts are current and disjoint: 291 total, 261 OVAL, 30 OCIL-only;',
        '249 draft compiled and 12 blocked automated. Secondary blocker counts overlap.', '',
        '## Reproduce generation', '', 'Use Python 3.12 and the toolchain dependencies recorded in `environment.txt`.',
        'Clone `vanderpol/scap-ng` at the toolchain SHA above. Clone',
        '`niwc-atlantic/scap-content-library` at the pinned source revision; ZIPs are under `Current/`.',
        'For each `name,pin` in `source-pins.json.sources`, run:', '', '```sh',
        'PYTHONPATH=.:tools python tools/v04_direct_converter.py "$NIWC/Current/$FILE" \\',
        '  --sha256 "$SHA256" --all-rules --output "$OUTPUT/$NAME"', '```', '',
        'Exact generating argv and host paths are retained in `invocations.json`; `.log` and',
        '`metrics.json` files record each command. The packaging script is included; its',
        '`invocations.json` precondition records completion of all six producer invocations.',
        'Run it with `--toolchain TOOLCHAIN --draft OUTPUT --evidence-id EVIDENCE_ID`.', '',
        '## Verification still required', '',
        'After publishing this DRAFT, run the exact-SHA six-benchmark source validity/independent',
        'proof gate and compare all preserved hashes. Reuse existing exact-SHA maintained CI;',
        'do not rerun the full suite solely to publish this preview. A later verified checkpoint',
        'will identify its exact code SHA, gates and proof limits separately. No scanner-runtime',
        'equivalence is claimed. Blocked content stays unconverted.']
    (output / 'README.md').write_text('\n'.join(lines) + '\n')
    environment = subprocess.check_output([sys.executable, '-m', 'pip', 'freeze'], text=True)
    (output / 'environment.txt').write_text(sys.version + '\n' + environment)
    inventory = []
    for path in sorted(output.rglob('*')):
        if path.is_file():
            raw = path.read_bytes()
            inventory.append({'path': str(path.relative_to(output)), 'bytes': len(raw),
                              'sha256': sha256(raw).hexdigest()})
    write_json(output / 'file-inventory.json', {'excludes_self': True, 'files': inventory})
    archive = output.with_suffix('.zip')
    assert not archive.exists()
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as package:
        for path in sorted(output.rglob('*')):
            if path.is_file():
                package.write(path, str(path.relative_to(output)))
    with zipfile.ZipFile(archive) as package:
        assert package.testzip() is None
        for item in inventory:
            assert sha256(package.read(item['path'])).hexdigest() == item['sha256']
    receipt = {'archive': str(archive), 'bytes': archive.stat().st_size,
               'sha256': sha256(archive.read_bytes()).hexdigest(), 'file_count': len(inventory) + 1,
               'summaries': summaries, 'retained_programs': retained}
    write_json(output.with_suffix('.receipt.json'), receipt)
    print(json.dumps(receipt, indent=2), flush=True)


if __name__ == '__main__':
    main()
