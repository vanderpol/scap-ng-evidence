"""Attach retained original-source rejection evidence without rerunning proofs."""
from collections import Counter
import csv
from hashlib import sha256
from importlib.metadata import version
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'six-source-draft-c65'
PRIOR = BASE / 'identity-six/report.json'


def save(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def main():
    assert ROOT.with_suffix('.receipt.json').exists(), 'Initial compilation/packaging must finish first'
    baseline = zipfile.ZipFile(ROOT.with_suffix('.zip'))
    metadata = json.loads(baseline.read('manifest.json'))
    old = json.loads(PRIOR.read_text())['sources']
    rows, rejected = [], []
    for name, summary in metadata['summaries'].items():
        packet = json.loads((PRIOR.parent / name / 'acceptance.json').read_text())
        assert packet['source']['sha256'] == metadata['input_pin']['sources'][name]['sha256']
        prior_rows = {r['rule']: r for r in packet['cases']}
        current = json.loads(baseline.read(name+'/ledger.json'))['rules']
        assert set(prior_rows) == {r['source_rule'] for r in current}
        for row in current:
            prior = prior_rows[row['source_rule']]
            validity = prior.get('source_validity')
            if validity and (validity['status'] != 'VALID' or any(i['kind']=='deprecated' for i in validity['issues'])):
                row['retained_original_source_validity'] = validity
                row['original_source_validity'] = 'INVALID_RETAINED_SOURCE_VALIDATION'
                row['draft_status'] = 'BLOCKED_INVALID_ORIGINAL_SOURCE'
                diagnostic = {'category': 'source-invalid', 'message': 'Original OVAL closure invalid/deprecated',
                              'issues': validity['issues']}
                if row['primary_diagnostic']:
                    row['secondary_diagnostics'].insert(0, row['primary_diagnostic'])
                row['primary_diagnostic'] = diagnostic
                row['secondary_diagnostics'].extend(validity['issues'])
                row['native_compilation_is_diagnostic_only'] = row['status']=='converted'
                rejected.append({'benchmark': name, 'rule': row['source_rule'], 'validity': validity,
                                 'raw_converted_candidate':row['status']=='converted'})
        compiled = ROOT / name / 'draft-compiled.scapng'
        if compiled.exists():
            compiled.rename(ROOT / name / 'diagnostic-candidates.scapng')
        compilation = json.loads(baseline.read(name+'/compilation.json'))
        compilation['purpose'] = 'Diagnostic native compilation only; known source-invalid candidates are disqualified in ledger'
        compilation['known_source_invalid_candidates'] = sum(r['draft_status']=='BLOCKED_INVALID_ORIGINAL_SOURCE' and r['status']=='converted' for r in current)
        save(ROOT / name / 'compilation.json', compilation)
        summary['statuses'] = dict(Counter(r['draft_status'] for r in current))
        summary['eligible_compiled_unproved'] = summary['statuses'].get('CONVERTED_COMPILED_UNPROVED',0)
        summary['primary_blocker_categories'] = dict(Counter(r['primary_diagnostic']['category']
            for r in current if r['draft_status'].startswith('BLOCKED') or r['draft_status']=='UNSUPPORTED_CHOICE'))
        save(ROOT / name / 'ledger.json', {'status':'DRAFT', 'rules':current})
        rows.extend(current)
    assert len(rows)==1567 and len({(r['benchmark'],r['source_rule']) for r in rows})==1567
    counts = Counter(r['draft_status'] for r in rows)
    assert counts['CONVERTED_COMPILED_UNPROVED']==1055 and counts['OCIL_ONLY_MANUAL_UNCONVERTED']==171
    assert sum(r['raw_converted_candidate'] for r in rejected)==2
    assert sum(r.get('previously_proved_program_retained',False) for r in rows)==1055
    assert sum(r['oval_bearing'] for r in rows)==1396
    # Source validation implementation and all vendored XSD/Schematron bytes
    # are unchanged across the owner schema sync. This reuses rejection evidence,
    # not a new claim that the current native output was independently proved.
    repository = Path('/workspace/scap-ng')
    identities = {}
    for path in ('tools/oval_source_validation.py','third_party/scap-1.4-schemas/oval_5.12.3'):
        identities[path] = {}
        for revision in ('a65aba621bb01571c7709466c1ebf08c087bfec6', metadata['toolchain_sha']):
            identities[path][revision] = subprocess.check_output(['git','-C',str(repository),'rev-parse',revision+':'+path],text=True).strip()
        assert len(set(identities[path].values()))==1
    save(ROOT / 'retained-source-rejections.json', {'prior_report_sha256':sha256(PRIOR.read_bytes()).hexdigest(),
        'per_source_report_sha256': {name: sha256((PRIOR.parent/name/'acceptance.json').read_bytes()).hexdigest() for name in old},
        'prior_toolchain_base':'a65aba621bb01571c7709466c1ebf08c087bfec6',
        'prior_converter_worktree':'included preserved enum-selector WIP; no source validator/XSD edits',
        'source_validation_git_identities':identities,'rejections':rejected,
        'scope':'Pinned-byte original-source rejection evidence only; no fresh native semantic proof'})
    save(ROOT / 'ledger.json', {'status':'DRAFT','toolchain_sha':metadata['toolchain_sha'],
        'counting':'One row per original Rule; primary statuses disjoint; secondary blockers overlap.','rules':rows})
    fields=['benchmark','source_rule','title','draft_status','oval_bearing','source_zip_sha256',
            'source_rule_sha256','native_assessment','program_sha256','primary_category','primary_message','secondary_messages']
    with (ROOT/'ledger.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for row in rows:
            primary=row.get('primary_diagnostic') or {}
            writer.writerow({**{k:row.get(k,'') for k in fields[:5]+fields[6:9]},
                'source_zip_sha256':row['source']['zip_sha256'],'primary_category':primary.get('category',''),
                'primary_message':primary.get('message',''),'secondary_messages':json.dumps(row['secondary_diagnostics'],sort_keys=True)})
    metadata.update(native_compiled_diagnostic_candidates=1057, converted_compiled_unproved=1055,
        known_original_invalid_candidates=2, known_source_invalid_rules=len(rejected), total_blocked_automated=341, ocil_only_manual=171,
        source_rejection_evidence='retained-source-rejections.json',
        original_source_validation='Two known rejections retained from pinned original-source report; no fresh full-source validation for draft',
        packaging_finalizer='finalize-six-draft.py; adjusts evidence labels only, never authored/native operands')
    save(ROOT/'manifest.json',metadata)
    shutil.copyfile(Path(__file__),ROOT/Path(__file__).name)
    (ROOT/'environment.txt').write_text(sys.version+'\n'+'\n'.join(name+'=='+version(name)
        for name in ('PyYAML','jsonschema','lxml','cryptography','referencing'))+'\n')
    text=['# SCAP-NG 0.4 six-benchmark converter — DRAFT','',
        '**Inspectable engineering draft. Not a verified release, complete lossless migration, or scanner result.**','',
        'Toolchain: `'+metadata['toolchain_sha']+'` (pristine checkout; local converter WIP excluded).',
        'NIWC pin: `'+metadata['input_pin']['revision']+'`; package hashes in `source-pins.json`.','',
        '## Inspect the draft','',
        'Open `ledger.csv` or `ledger.json`: all 1,567 source Rules are accounted for, including',
        '1,396 OVAL-bearing and 171 OCIL-only Rules. Primary statuses are disjoint.',
        'There are 1,055 eligible schema-valid/compiled candidates, 341 blocked automated Rules,',
        'and 171 OCIL-only/manual Rules. No independent source proof is newly claimed for this draft.','',
        'Each benchmark directory has actual generated `authoring/**/*.yaml` and `.json`,',
        'complete `coverage.json` and `source-trace.json`, a ledger, and compilation evidence.',
        'The raw converter emits 1,057 authoring candidates. Two banner Rules are already known',
        'to fail original Schematron checks: RHEL `SV-270174` and Oracle Linux `SV-271689`.',
        'They are explicitly **BLOCKED_INVALID_ORIGINAL_SOURCE**, not successful conversions.',
        'Their raw native output is retained only for diagnosis. `diagnostic-candidates.scapng`',
        'files include all raw candidates and **must not be treated as accepted assessment packages**.',
        'Read `retained-source-rejections.json` for the exact original validity failures and source pins.','',
        '| Benchmark | Total | OVAL | Eligible compiled/unproved | Blocked automated | OCIL-only |',
        '| --- | ---: | ---: | ---: | ---: | ---: |']
    for name,s in metadata['summaries'].items():
        counts=s['statuses'];manual=counts.get('OCIL_ONLY_MANUAL_UNCONVERTED',0);eligible=s['eligible_compiled_unproved']
        text.append(f"| {name} | {s['total_rules']} | {s['oval_bearing']} | {eligible} | {s['total_rules']-manual-eligible} | {manual} |")
    text += ['', 'Server 2025 counts are current: 291 total, 261 OVAL, 30 OCIL-only, 249 eligible',
        'compiled/unproved and 12 blocked automated. Secondary blocker entries overlap; do not sum them.',
        'DNS/Apache automated Rules stop at strict unresolved checklist catalog hrefs. The ledger',
        'retains exact missing references and all discoverable secondary node diagnostics; no aliases are guessed.','',
        '## Checks and limits','',
        'Fresh draft checks: every producer completed successfully, authoring schema validation,',
        'JSON/YAML value equality, native semantic compilation, all 1,057 diagnostic program operands,',
        'bundle integrity, and all 1,055 previous proof-floor program hashes retained.',
        'Program hash retention does not replace fresh independent OVAL semantic comparison.',
        'Known original-source invalidity is carried forward using unchanged validator/XSD bytes.',
        'Full original XSD/Schematron and source/native proof gates are deferred until after publication.',
        'Exact-toolchain maintained CI already passed: 3,264 tests, zero failures/errors, one existing skip:',
        'https://github.com/vanderpol/scap-ng/actions/runs/40733597054 . No duplicate full suite was launched.',
        'Applicability/CPE, full policy/remediation/scoring, manual execution and scanner runtime remain unconverted/unproved.',
        'A subsequent verified checkpoint requires exact-SHA six-source proof and retention gates.','',
        '## Reproduce','',
        'Clone `vanderpol/scap-ng` at the exact toolchain SHA; use Python 3.12 and `environment.txt`.',
        'Clone `niwc-atlantic/scap-content-library` at the source pin. ZIPs are under `Current/`.',
        'For each entry in `source-pins.json.sources`, run from the toolchain checkout:','', '```sh',
        'PYTHONPATH=.:tools python tools/v04_direct_converter.py "$NIWC/Current/$FILE" \\',
        '  --sha256 "$SHA256" --all-rules --output "$OUTPUT/$NAME"','```','',
        'Actual argv/host paths are in `invocations.json`; logs and per-source metrics are retained.',
        'Packaging uses the included `package-six-draft.py` (native compilation and hash checks).',
        'The included finalizer records two retained source rejections without changing any native operands.',
        'Both helper scripts record original host paths for this evidence run; replace them with your local',
        'toolchain/output/report paths when reproducing packaging. See their source and `manifest.json`.',
        'No schema, compiler, scanner, editor or production `all_exist` behavior was changed.']
    (ROOT/'README.md').write_text('\n'.join(text)+'\n')
    inventory=[]
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and path!=ROOT/'file-inventory.json':
            raw=path.read_bytes();inventory.append({'path':str(path.relative_to(ROOT)),'bytes':len(raw),'sha256':sha256(raw).hexdigest()})
    save(ROOT/'file-inventory.json',{'excludes_self':True,'files':inventory})
    archive=ROOT.with_suffix('.zip');initial=BASE/'six-source-draft-c65.initial-packaging.zip'
    baseline.close()
    assert archive.exists() and not initial.exists();archive.rename(initial)
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for path in sorted(ROOT.rglob('*')):
            if path.is_file():z.write(path,str(path.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in inventory:assert sha256(z.read(item['path'])).hexdigest()==item['sha256']
    receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),
             'files':len(inventory)+1,'eligible_compiled_unproved':1055,'native_compiled_diagnostics':1057,
             'blocked_automated':341,'ocil_only_manual':171,'source_rules':1567,'oval_rules':1396,
             'retained_program_hashes':1055,'source_invalid_rejections':rejected}
    save(ROOT.with_suffix('.final-receipt.json'),receipt)
    print(json.dumps({k:v for k,v in receipt.items() if k!='source_invalid_rejections'},indent=2))


if __name__=='__main__':main()
