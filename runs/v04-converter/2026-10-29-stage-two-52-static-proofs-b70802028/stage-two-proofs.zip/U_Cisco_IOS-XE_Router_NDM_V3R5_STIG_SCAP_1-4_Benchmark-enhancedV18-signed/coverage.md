# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"NOT_SELECTED": 10, "PROVED": 32}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_mil.disa.stig.cisco_rule_SV-215807r1186318_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215808r1186320_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215809r1186322_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215810r1186324_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215811r1186326_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215812r1137875_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215813r960840_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215814r960843_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215815r1186328_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215817r960894_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215818r960897_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215819r1186330_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215820r960933_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215821r960936_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215822r960960_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215823r1043177_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215824r1051115_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215826r1015288_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215827r1015289_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215828r1015290_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215829r1015291_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215830r1015292_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215831r1043189_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215832r1015294_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215833r961068_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215834r1186332_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215836r961392_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215837r991886_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215838r1015295_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215841r1107207_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215842r961506_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215843r1050862_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215844r961554_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215845r961557_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215848r1186334_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215849r961824_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215850r1186336_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215854r1156415_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215855r1069501_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-215856r991889_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-220139r1137890_rule | PROVED | [] |
| xccdf_mil.disa.stig.cisco_rule_SV-220140r961863_rule | NOT_SELECTED | [] |
