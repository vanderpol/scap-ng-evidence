"""Summarize existing, pinned investigation records; never runs conversion."""
import argparse,csv,hashlib,json,re
from collections import Counter,defaultdict
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--recovery-root',type=Path,default=Path(__file__).parent)
parser.add_argument('--output',type=Path,default=Path('/workspace/reports/scap-ng-source-oddities-20261029'))
args=parser.parse_args()
ROOT=args.recovery_root
OUT=args.output
OUT.mkdir(parents=True,exist_ok=True)
SOURCE_SHA='2e5eaec0caf031d792ea6dd996a649e48a91c24d'
catalog=json.loads((ROOT/'blocker-audit.json').read_text())
known=json.loads((ROOT/'known-invalid-final.json').read_text())
remaining=json.loads((ROOT/'remaining-39-source-validity.json').read_text())['cases']
pins={p['file']:p for p in json.loads((ROOT/'source-pins.json').read_text())['sources']}
rows={}
for path in sorted((ROOT/'all-65-draft').glob('*/ledger.json')):
    for row in json.loads(path.read_text())['rules']:
        key=path.parent.name+'.zip',row['source_rule']
        rows[key]={**row,'file':key[0]}
assert len(rows)==8892

definitions=[
 ('O01','Foreign namespace on catalog URI entries','Producer packaging','Confirmed source encoding; standard URI semantics absent','Emit XML Catalog cat:uri; preserve exact names, references and versioned provenance.'),
 ('O02','Stale standard catalog references','Producer packaging','Confirmed dangling standard entries in 20 affected sources','Rebuild and check the complete stream graph; do not leave references to removed components.'),
 ('O03','Missing record datatype on cmdlet parameters','Source author/generator','Pinned original Schematron failure','Declare parameters datatype=record even when xsi:nil; revalidate intended command and inputs.'),
 ('O04','Pattern path combined with prohibited recursion behaviors','Source author/generator','Pinned original Schematron failure','Choose and validate intended pattern-versus-recursion strategy; do not blindly remove recursion.'),
 ('O05','Pattern entity uses incompatible/default operation','Source author/generator','Pinned original Schematron failure','Review intended regex and explicitly use operation=pattern match where required.'),
 ('O06','Test none_exist also references a State','Source author','Pinned original Schematron failure','Separate Test absence from comparison of existing Items; review the intended condition before changing it.'),
 ('O07','Object, State or Filter has the wrong capability family','Source author/generator','Pinned original Schematron failure','Use matching test/object/state types and compatible Filter States; preserve intended returned fields.'),
 ('O08','Deprecated Tests, Objects, States or attribute values','Source maintenance plus standards support policy','Effective Test exclusions or observed original deprecation diagnostics','Use supported replacements after semantic review; honor explicit reinstatement overrides.'),
 ('O09','Nonstandard independent.sqlext packages','Extension publisher and SCAP-NG support','Nonstandard extension; not established malformed content','Supply a versioned extension contract/schema/collector or author a reviewed standard equivalent.'),
 ('O10','Integer count consumed by string functions','OVAL standards/validator review; source author involved','Schematron failure conflicts with function-casting prose','Resolve casting scope before changing otherwise intentional count-to-regex formatting.'),
 ('O11','IOS XE text and regex captures declared integer','Source author','Strong content-defect candidate; runtime untested','Review text-bearing Variable datatypes and downstream consumers in SV-215833.'),
 ('O12','IOS XE split delimiter is literal backslash+n','Source author and collector implementer','Confirmed XML lexical value; runtime escape behavior untested','Specify intended delimiter explicitly and test against actual newline-delimited configuration.'),
 ('O13','IOS XE Switch Rule IDs carry ms.dns prefix','Source generator/provenance','Confirmed naming anomaly, not proof of wrong check logic','Correct future ID templates; preserve existing identity or migrate references deliberately.'),
 ('O14','all_exist collection-population ambiguity','SCAP-NG/OVAL semantic decision','Valid source construct; unrestricted equivalence unproved','Preserve original token and define complete, missing-target, error, unknown and incomplete outcomes.'),
 ('O15','XCCDF/OVAL check imports and exports','SCAP-NG converter/binding contract','Unsupported binding behavior, not established source defect','Retain all inputs/bindings; implement support rather than deleting required organizational values.'),
 ('O16','Multiple aggregation components','SCAP-NG collection-expression contract','Unsupported collection expression, not established source defect','Preserve order, cardinality and error propagation; do not discard components.'),
 ('O17','Functions: count, split and substring','SCAP-NG function contract/implementation','Unsupported function, not established source defect','Implement and independently prove function behavior; retain original operations.'),
 ('O18','Acquisition comparison/type contracts','SCAP-NG capability/collection contract','Original closures validated; acquisition semantics unresolved','Preserve case-insensitive command and version-typed module acquisition.'),
 ('O19','Ordered comparison on non-integer source datatype','SCAP-NG converter/number contract','Ten investigated original closures valid/nondeprecated','Retain original datatype and comparison; do not truncate or coerce to integer.'),
 ('O20','Field absence still carries a literal comparator','Source intent review plus converter contract','Nine investigated original closures valid/nondeprecated','Review redundant comparison intent; distinguish field absence from no matching values.'),
 ('O21','Supported-source field missing from native crosswalk','SCAP-NG mapping contract','Two investigated original closures valid/nondeprecated','Review missing ghost_file/configuration_file fields; do not drop filters or fields.'),
 ('O22','Variable-source attributes reach an unsupported function','SCAP-NG converter/function contract','Two investigated original closures valid/nondeprecated','Retain source attributes and subsequent split dependency; implement supported defaults/functions.'),
 ('O23','IOS XE independent-reader coverage gap, resolved','SCAP-NG tooling','38 original Rules now independently static-proved','No source change required; preserve the published DRAFT hashes and static/runtime distinction.'),
]
defs={x[0]:dict(zip(['id','title','likely_control','confidence','suggested_action'],x)) for x in definitions}
found=defaultdict(set);validation={};messages=defaultdict(list)
def mark(identifier,key):
    assert key in rows,key
    found[key].add(identifier)
def observe(key,validity):
    validation[key]=validity
    for issue in validity.get('issues',[]):
        message=issue.get('message','');messages[key].append(message)
        for identifier,predicate in [
            ('O03',"parameters entity of a cmdlet_object must be 'record'" in message),
            ('O04','behavior MUST not be used when a pattern match' in message),
            ('O05','operation attribute for the pattern entity' in message),
            ('O06','No state should be referenced' in message),
            ('O07','must reference a appcmd_' in message or 'wrong type' in message),
            ('O08',issue.get('kind')=='deprecated'),
            ('O10','variable referenced by the concat function' in message or 'variable referenced by the regex_capture function' in message),
        ]:
            if predicate:mark(identifier,key)
for r in known:
    value=json.loads(r['reason'])
    validity=value if isinstance(value,dict) else {'status':'INVALID','issues':value}
    observe((r['file'],r['rule']),validity)
for r in remaining:observe((r['file'],r['rule']),r['source_validity'])
for source in catalog['catalog']:
    for ref in source['references']:
        key=source['source_pin']['file'],ref['rule'];mark('O01',key)
        if source['catalog_errors']:mark('O02',key)
for key,row in rows.items():
    message=row.get('primary_blocker',{}).get('message','')
    if row['draft_status']=='BLOCKED_EXPLICIT':
        if message.startswith('Effectively deprecated original'):mark('O08',key)
        if 'sqlext' in message:mark('O09',key)
        pairs=[('O14',message=='unsupported Test existence: all_exist'),('O15',message=='OVAL check imports/exports unsupported'),
            ('O16',message=='multiple aggregation components need an approved collection expression'),
            ('O17',message.startswith('unsupported function:')),('O18',message=='unsupported acquisition parameter comparison/type'),
            ('O19',message=='ordered comparison expansion requires integer source datatype'),
            ('O20',message=='comparator-bearing absence blocked'),('O21',message=='unsupported State field/namespace'),
            ('O22',message=="var_ref: unsupported attributes ['datatype', 'operation']")]
        for identifier,predicate in pairs:
            if predicate:mark(identifier,key)
    if 'IOS-XE_Switch' in key[0] and '.ms.dns_rule_' in key[1]:mark('O13',key)
    if 'IOS-XE_Router_NDM' in key[0] and 'SV-215833' in key[1]:mark('O11',key);mark('O12',key)
    if 'IOS-XE_Router' in key[0] and row['draft_status']=='CONVERTED_SCHEMA_VALID_UNVERIFIED':mark('O23',key)
blocked={k for k,r in rows.items() if r['draft_status']=='BLOCKED_EXPLICIT'}
assert len(blocked)==2981
assert blocked<=set(found),[(k,rows[k]['primary_blocker']) for k in blocked-set(found)]
assert len(validation)==71
for identifier in defs:
    keys=sorted(k for k,findings in found.items() if identifier in findings)
    defs[identifier]['affected_rules']=len(keys)
    defs[identifier]['affected_source_count']=len({k[0] for k in keys})
    defs[identifier]['rules']=[{'file':k[0],'rule':k[1]} for k in keys]

columns=['finding_ids','source_file','rule','title','draft_status','current_static_proof_status','primary_diagnostic','original_validity_if_investigated','deprecation_observed','likely_control','suggested_actions','validator_messages','source_rule_sha256','source_zip_sha256','pinned_source_url']
with (OUT/'affected-rules.csv').open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
    for key,ids in sorted(found.items()):
        row=rows[key];pin=pins[key[0]];v=validation.get(key)
        item={'finding_ids':'; '.join(sorted(ids)),'source_file':key[0],'rule':key[1],'title':row.get('title',''),
            'draft_status':row['draft_status'],'current_static_proof_status':'PROVED_IN_SEPARATE_STAGE_TWO' if 'O23' in ids else 'NOT_PROMOTED_BY_THIS_REPORT',
            'primary_diagnostic':row.get('primary_blocker',{}).get('message',''),
            'original_validity_if_investigated':v['status'] if v else 'NOT_ESTABLISHED_BY_THIS_REPORT',
            'deprecation_observed':any(i.get('kind')=='deprecated' for i in v['issues']) if v else ('EFFECTIVE_TEST_EXCLUSION' if 'O08' in ids else ''),
            'likely_control':'; '.join(sorted({defs[i]['likely_control'] for i in ids})),
            'suggested_actions':' | '.join(defs[i]['suggested_action'] for i in sorted(ids)),
            'validator_messages':' | '.join(dict.fromkeys(messages[key])),
            'source_rule_sha256':row['source_rule_sha256'],'source_zip_sha256':pin['sha256'],
            'pinned_source_url':'https://github.com/niwc-atlantic/scap-content-library/blob/8c8e5dff860af6b1290ee9273a282db24278f8d5/'+pin['repository_path']}
        writer.writerow(item)
summary={'report_date':'2026-10-29','source_repository':'vanderpol/scap-ng','source_commit':SOURCE_SHA,
    'original_revision':'8c8e5dff860af6b1290ee9273a282db24278f8d5','scope':'All oddities identified by the existing pinned conversion and investigation records; not a new exhaustive semantic audit.',
    'corpus':{'benchmarks':65,'rules':8892,'automated_attempts':7239,'static_primary_proofs':4258,'blocked_automated_rules':2981,'manual_ocil_only':1653},
    'unique_indexed_rules':len(found),'blocked_rules_in_index':len(blocked),'original_closures_with_detailed_validation_records':len(validation),
    'findings':list(defs.values()),'catalog_sources':[{k:s[k] for k in ['source_pin','affected_rules','catalog_errors']} for s in catalog['catalog']],
    'detailed_validation':[{'file':k[0],'rule':k[1],'validity':v} for k,v in sorted(validation.items())],
    'limits':['Finding counts overlap and must not be summed','Source validity does not establish intended behavior','No scanner-runtime claims','No originals, native grammar or validators changed','Producer control is suggested, not assumed'],
    'inputs_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in ['blocker-audit.json','known-invalid-final.json','remaining-39-source-validity.json','source-pins.json']}}
(OUT/'findings.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k in ['corpus','unique_indexed_rules','blocked_rules_in_index','original_closures_with_detailed_validation_records']},indent=2))
for d in defs.values():print(d['id'],d['affected_rules'],d['title'])
