# SCAP-NG source oddities report

Start with REPORT.pdf or REPORT.html. Use affected-rules.csv to filter the
3,024 distinct Rules by finding ID, source, exact Rule ID or suggested area
of control. REPORT.md is the plain-text copy. findings.json retains the
23 classes, complete memberships and 71 original closure validation records.
The two adjacent investigation JSON files contain exact IOS XE excerpts and
population/catalog evidence. Counts overlap. These are observed static findings,
not a complete scanner or source-semantic audit. No originals were changed.

To reproduce the CSV/JSON from the existing pinned evidence (no conversion):
1. Download and extract the complete DRAFT archive at evidence commit
   57032484aa098d18fecf69fe186b2ef753473245 into INPUTS/all-65-draft/.
2. Copy its source-pins.json and known-invalid-final.json to INPUTS/.
3. Extract investigation.zip at evidence commit
   5b1b027623cd454b263aa60e16122bba503566a9 into INPUTS/. It supplies
   blocker-audit.json and remaining-39-source-validity.json.
4. Run: python build_owner_report.py --recovery-root INPUTS --output OUTPUT
The generating source records are pinned in findings.json. Reproduction only
joins existing ledgers/diagnostics; it does not regenerate or repair content.
