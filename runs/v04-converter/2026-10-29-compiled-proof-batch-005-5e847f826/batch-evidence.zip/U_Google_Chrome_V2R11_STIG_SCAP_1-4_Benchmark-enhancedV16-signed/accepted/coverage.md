# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"NOT_SELECTED": 21, "PROVED": 25}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_mil.disa.stig_rule_SV-221558r960804_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221559r961083_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221561r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221562r960879_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221563r1015468_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221564r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221565r960963_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-221566r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221567r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221570r960921_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221571r987620_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221572r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221573r987620_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221574r961863_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-221575r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221576r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221577r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221578r960864_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221579r961893_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221580r961083_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221581r961128_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221584r961683_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-221586r960879_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-221587r960879_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221588r1106670_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-221590r961083_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221591r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221594r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221595r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221596r961092_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-221597r961083_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-221598r961083_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-221599r961167_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-226401r961083_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-226402r961083_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-226403r961083_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-226404r961083_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-241787r960963_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-245538r961470_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-245539r960864_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-275780r1106603_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-275781r1106671_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-275782r1106672_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-275783r1106612_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-275784r1106615_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-275785r1106673_rule | NOT_SELECTED | [] |
