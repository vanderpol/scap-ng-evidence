import json,zipfile,sys
from pathlib import Path
sys.path.insert(0,'/workspace/scap-ng/tools')
from v04_direct_scap_source import digest,SourceModel
from v04_direct_converter import convert_rule,load_mappings
from v04_native_bundle_compiler import compile_assessment_program

ROOT=Path(__file__).parent
EV=Path('/workspace/scap-ng-evidence/runs/v04-converter')
SRC=Path('/workspace/scap-ng')
records={};known={}
def reject(file,rule,reason):known[file+'!'+rule]={'file':file,'rule':rule,'reason':reason}
with zipfile.ZipFile(EV/'2026-10-28-niwc-65-draft-248895772/niwc-65-draft-248895772.zip') as z:
    for r in json.loads(z.read('ledger.json'))['rules']:
        if r['draft_status']=='BLOCKED_INVALID_ORIGINAL_SOURCE':
            reject(r['benchmark']+'.zip',r['source_rule'],r['primary_blocker']['message'])
folders=[EV/'2026-10-28-six-primary-static-verified-248895772']+sorted(EV.glob('2026-10-29-compiled-proof-batch-*'))
for folder in folders:
    with zipfile.ZipFile(next(folder.glob('*.zip'))) as z:
        for n in z.namelist():
            if not n.endswith('/acceptance.json'):continue
            d=json.loads(z.read(n));file=d['source']['file']
            programs={p['assessment']:p['program_sha256'] for p in d['programs']}
            for r in d['cases']:
                if r['outcome']=='BLOCKED' and r.get('diagnostic')=='original OVAL closure invalid/deprecated':
                    reject(file,r['rule'],json.dumps(r['source_validity']))
                if r['outcome']!='PROVED':continue
                path=n.rsplit('/',1)[0]+'/authoring/direct-slice/assessments/'+r['assessment']+'.json'
                a=json.loads(z.read(path))['assessment']
                record={'source_rule_sha256':r['source_rule_sha256'],'source_zip_sha256':d['source']['sha256'],
                        'authoring_sha256':digest(a),'program_sha256':programs[r['assessment']],
                        'evidence':str(folder.relative_to(EV))+'/'+n}
                key=file+'!'+r['rule']
                if key in records:assert all(records[key][k]==record[k] for k in ['source_rule_sha256','authoring_sha256','program_sha256'])
                records[key]=record
for name in ['v04-nil-filename-defaults-20261029.json','v04-ntuser-empty-state-recovery-20261029.json']:
    d=json.loads((SRC/'docs/audit'/name).read_text())
    for r in d['original_primary_additions']:
        pin=r['source'];source=SourceModel(ROOT/'inputs'/pin['file'],pin['sha256'])
        docs,_=convert_rule(source,r['rule'],load_mappings())
        a=next(v['assessment'] for v in docs.values() if 'assessment' in v)
        expected=r['programs'][0]['program_sha256']
        assert digest(compile_assessment_program(a))==expected
        records[pin['file']+'!'+r['rule']]={'source_rule_sha256':r['source_rule_sha256'],
            'source_zip_sha256':pin['sha256'],'authoring_sha256':digest(a),'program_sha256':expected,'evidence':'docs/audit/'+name}
    for r in d.get('remaining_guard_audit',{}).get('cases',[]):
        if r['original_closure_status']=='INVALID':reject(r['source']['file'],r['rule'],json.dumps(r['source_issues']))
assert len(records)==4206,len(records)
assert len(known)==28,len(known)
(ROOT/'proof-baseline.json').write_text(json.dumps({'records':records},indent=2)+'\n')
(ROOT/'known-invalid.json').write_text(json.dumps(list(known.values()),indent=2)+'\n')
print('Recovered',len(records),'published proof hashes and',len(known),'source exclusions')
