import concurrent.futures, hashlib, json, urllib.request
from pathlib import Path

ROOT=Path(__file__).parent
PINS=Path('/workspace/scap-ng-evidence/runs/v04-converter/2026-10-28-niwc-65-draft-248895772/source-pins.json')
pins=json.loads(PINS.read_text())
(ROOT/'source-pins.json').write_bytes(PINS.read_bytes())
(ROOT/'inputs').mkdir(exist_ok=True)
def recover(pin):
    path=ROOT/'inputs'/pin['file']
    if not path.exists():
        url='https://raw.githubusercontent.com/'+pins['repository']+'/'+pins['revision']+'/'+pin['repository_path']
        with urllib.request.urlopen(url,timeout=90) as response: raw=response.read()
        assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
        assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==pin['git_blob_sha']
        path.write_bytes(raw)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==pin['sha256']
    return pin['file']
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
    for name in pool.map(recover,pins['sources']): print(name,flush=True)
