import concurrent.futures,hashlib,json,pathlib,shutil,urllib.request
root=pathlib.Path('/workspace/recovery-20261028'); destination=root/'niwc-65-inputs';destination.mkdir(exist_ok=True)
rows=json.loads((root/'niwc-65-source-tree.json').read_text()); pin='8c8e5dff860af6b1290ee9273a282db24278f8d5'; cache={}
for directory in (pathlib.Path('/workspace/.onboarding/package-acceptance/inputs'),pathlib.Path('/workspace/.onboarding/absence-integration/pinned-source')):
 for p in directory.rglob('*.zip'):cache.setdefault(p.name,[]).append(p)
def matches(data,row):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['sha']
def recover(row):
 target=destination/pathlib.Path(row['path']).name
 if target.exists() and matches(target.read_bytes(),row):data=target.read_bytes()
 else:
  data=None
  for p in cache.get(target.name,[]):
   b=p.read_bytes()
   if matches(b,row):data=b;break
  if data is None:
   with urllib.request.urlopen('https://raw.githubusercontent.com/niwc-atlantic/scap-content-library/'+pin+'/'+row['path'],timeout=60) as response:data=response.read()
  assert len(data)==row['size'] and matches(data,row),row['path']
  target.write_bytes(data)
 return {'file':target.name,'repository_path':row['path'],'git_blob_sha':row['sha'],'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:result=list(pool.map(recover,rows))
assert len(result)==65
(root/'niwc-65-source-pins.json').write_text(json.dumps({'repository':'niwc-atlantic/scap-content-library','revision':pin,'sources':result},indent=2)+'\n')
print('Recovered and Git-blob-verified',len(result),'individual original ZIPs')
