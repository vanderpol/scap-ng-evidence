"""Designated pinned NIWC 65-source DRAFT checkpoint; never a routine regression.
Run with PYTHONPATH=<pinned scap-ng>/tools python build_65_draft.py.
Inputs: sibling niwc-65-source-pins.json and niwc-65-inputs/.
No input is repaired; compilation is not original-source or runtime proof.
"""
from pathlib import Path
import concurrent.futures,csv,hashlib,json,os,subprocess,sys,time
from v04_direct_scap_source import SourceModel,OVAL
from v04_direct_converter import convert_benchmark
from v04_direct_yaml import authoring_yaml
from v04_native_bundle_compiler import build_bundle
from audit_v04_direct_benchmark import verify_compiled
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'niwc-65-draft-248895772'
SQLEXT={'U_MS_SQL_Server_2016_Database_V3R4_STIG_SCAP_1-4_Benchmark-enhancedV13-signed.zip','U_MS_SQL_Server_2016_Instance_V3R6_STIG_SCAP_1-4_Benchmark-enhancedV14-signed.zip','U_MS_SQL_Server_2022_Database_V1R2_STIG_SCAP_1-4_Benchmark-enhancedV8-signed.zip','U_MS_SQL_Server_2022_Instance_V1R3_STIG_SCAP_1-4_Benchmark-enhancedV8-signed.zip'}
def build(pin):
 key=pin['file'].removesuffix('.zip');target=OUT/key;target.mkdir()
 source=SourceModel(ROOT/'niwc-65-inputs'/pin['file'],pin['sha256'],inventory_broken_references=True)
 exception=pin['file'] in SQLEXT
 if exception:assert any('sqlext' in n.tag for c in source.components.values() for n in c.iter())
 docs,trace,coverage=convert_benchmark(source,inventory_only=exception)
 programs=[]
 if docs:
  bundle,metrics=build_bundle(docs);programs=verify_compiled(docs,bundle)
  (target/'diagnostic-candidates.scapng').write_bytes(bundle)
  for relative,doc in docs.items():
   p=target/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(doc,indent=2)+'\n');p.with_suffix('.yaml').write_text(authoring_yaml(doc))
 for row in coverage['rules']:
  oval=any(c['system']==OVAL for c in row['checks'])
  status=('OCIL_ONLY_MANUAL_UNCONVERTED' if not oval else 'BLOCKED_SOURCE_PACKAGE_SQLEXT' if exception else 'CONVERTED_COMPILED_UNPROVED_ORIGINAL_VALIDITY_NOT_RUN' if row['status']=='converted' else 'BLOCKED')
  row.update(benchmark=key,oval_bearing=oval,draft_status=status,independent_source_proof='NOT_RUN',original_source_validation='NOT_RUN',scanner_evaluated=False)
  if exception and oval:row['primary_blocker']={'category':'source-package-exception','message':'nonstandard source capability independent.sqlext; package held fail-closed'}
 (target/'ledger.json').write_text(json.dumps(coverage,indent=2)+'\n');(target/'source-trace.json').write_text(json.dumps(trace,indent=2)+'\n');(target/'compilation.json').write_text(json.dumps(programs,indent=2)+'\n')
 from collections import Counter
 summary={'file':pin['file'],'source_sha256':pin['sha256'],'source_package_exception':exception,'total_rules':len(coverage['rules']),'statuses':dict(Counter(r['draft_status'] for r in coverage['rules'])),'compiled_programs':len(programs)}
 (target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(pin['file'],json.dumps(summary['statuses']),flush=True)
 return summary
if __name__=='__main__':
 OUT.mkdir(exist_ok=False);pins=json.loads((ROOT/'niwc-65-source-pins.json').read_text());assert len(pins['sources'])==65
 with concurrent.futures.ProcessPoolExecutor(max_workers=3) as pool:summaries=list(pool.map(build,pins['sources']))
 (OUT/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n');(OUT/'summaries.json').write_text(json.dumps(summaries,indent=2)+'\n')
 rows=[]
 for p in sorted(OUT.glob('*/ledger.json')):rows.extend(json.loads(p.read_text())['rules'])
 assert len(rows)==len({(r['benchmark'],r['source_rule']) for r in rows})
 (OUT/'ledger.json').write_text(json.dumps({'counting':'One row per original Rule; source-package exception separate from per-Rule capability; secondary blockers overlap','rules':rows},indent=2)+'\n')
 with (OUT/'ledger.csv').open('w',newline='') as f:
  columns=['benchmark','source_rule','draft_status','oval_bearing','needed_capabilities','primary_blocker','blockers'];w=csv.DictWriter(f,fieldnames=columns);w.writeheader()
  for row in rows:w.writerow({k:json.dumps(row.get(k)) if isinstance(row.get(k),(dict,list)) else row.get(k) for k in columns})
 print('COMPLETE',len(summaries),'benchmarks',len(rows),'Rules',flush=True)
