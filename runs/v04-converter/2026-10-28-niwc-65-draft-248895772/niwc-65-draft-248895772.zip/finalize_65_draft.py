"""Evidence-only finalizer. No authored/native operands are changed.
Reuses the separately source-proved six-source primary gate only after exact
Assessment/program hash matching; other sources retain explicit unproved status.
"""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
import csv,hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'niwc-65-draft-248895772'
SHA='24889577233c6a75e739676adffe8f676a0f9f3b'
REPO=Path(__import__('v04_direct_converter').__file__).resolve().parents[1]
SIX=json.loads((REPO/'tests/fixtures/v04-direct-six-sources.json').read_text())
receipt=json.loads((REPO/'docs/audit/v04-shellcommand-regex-recovery-20261028.json').read_text())
allrows=[];summaries=[];retained=0
for pin in json.loads((OUT/'source-pins.json').read_text())['sources']:
 target=OUT/pin['file'].removesuffix('.zip');coverage=json.loads((target/'ledger.json').read_text());programs=json.loads((target/'compilation.json').read_text());by_program={p['assessment']:p['program_sha256'] for p in programs}
 matched=next((k for k,v in SIX['sources'].items() if v['file']==pin['file']),None)
 if matched:
  assert pin['sha256']==SIX['sources'][matched]['sha256']
  acceptance=json.loads((ROOT/'shellcommand-six-acceptance'/matched/'acceptance.json').read_text());cases={c['rule']:c for c in acceptance['cases']};proof_programs={p['assessment']:p['program_sha256'] for p in acceptance['programs']}
  for row in coverage['rules']:
   case=cases[row['source_rule']]
   if case['outcome']=='PROVED':
    assert row['status']=='converted';assert by_program[case['assessment']]==proof_programs[case['assessment']]
    row.update(draft_status='SOURCE_PROVED_COMPILED_PRIMARY_ONLY',original_source_validation='VALID_NONDEPRECATED_SIX_SOURCE_GATE',independent_source_proof='RETAINED_SIX_SOURCE_GATE_EXACT_PROGRAM_HASH',assessment=case['assessment'],program_sha256=by_program[case['assessment']]);retained+=1
   elif case.get('source_validity'):
    row.update(draft_status='BLOCKED_INVALID_ORIGINAL_SOURCE',original_source_validation=case['source_validity'],primary_blocker={'category':'source-invalid','message':'Original OVAL closure invalid/deprecated'})
 summaries.append({'file':pin['file'],'source_sha256':pin['sha256'],'source_package_exception':pin['file'] in __import__('build_65_draft').SQLEXT,'total_rules':len(coverage['rules']),'statuses':dict(Counter(r['draft_status'] for r in coverage['rules'])),'compiled_diagnostic_programs':len(programs)})
 (target/'ledger.json').write_text(json.dumps(coverage,indent=2)+'\n');(target/'summary.json').write_text(json.dumps(summaries[-1],indent=2)+'\n');allrows.extend(coverage['rules'])
assert retained==1072;assert len(summaries)==65;assert sum(s['source_package_exception'] for s in summaries)==4
assert len(allrows)==len({(r['benchmark'],r['source_rule']) for r in allrows})
counts=Counter(r['draft_status'] for r in allrows);primary=Counter();secondary=Counter();examples=defaultdict(list)
for r in allrows:
 if r['draft_status'].startswith('BLOCKED'):
  m=r.get('primary_blocker',{}).get('message');assert m;primary[m]+=1
  if len(examples[m])<2:examples[m].append({'benchmark':r['benchmark'],'source_rule':r['source_rule']})
  secondary.update({b['message'] for b in r.get('blockers',[])})
assert sum(primary.values())==sum(n for status,n in counts.items() if status.startswith('BLOCKED'))
(OUT/'ledger.json').write_text(json.dumps({'counting':'One row per original Rule; primary statuses disjoint; secondary diagnostics overlap','rules':allrows},indent=2)+'\n')
with (OUT/'ledger.csv').open('w',newline='') as f:
 columns=['benchmark','source_rule','draft_status','oval_bearing','needed_capabilities','primary_blocker','blockers'];w=csv.DictWriter(f,fieldnames=columns);w.writeheader()
 for row in allrows:w.writerow({k:json.dumps(row.get(k)) if isinstance(row.get(k),(dict,list)) else row.get(k) for k in columns})
summary={'benchmarks':65,'source_package_exceptions':4,'total_rules':len(allrows),'oval_bearing_rules':sum(r['oval_bearing'] for r in allrows),'statuses_disjoint':dict(counts),'primary_blocker_messages_disjoint':dict(primary.most_common()),'secondary_diagnostic_rule_presence_overlapping':dict(secondary.most_common()),'representatives':examples,'sources':summaries}
(OUT/'summaries.json').write_text(json.dumps(summary,indent=2)+'\n')
for f in ('build_65_draft.py','finalize_65_draft.py','recover_65_sources.py','niwc-65-source-tree.json'):shutil.copy2(ROOT/f,OUT/f)
manifest={'evidence_id':'v04-niwc-65-draft-20261028-248895772','kind':'production-migration-engineering-draft','status':'DRAFT — NOT RUNTIME VERIFIED','created_at':datetime.now(timezone.utc).isoformat(),'source_scap_ng_repository':'vanderpol/scap-ng','toolchain_sha':SHA,'generating_tool':'tools/v04_direct_converter.py:convert_benchmark plus included build_65_draft.py','inputs':'source-pins.json; NIWC 8c8e5dff860af6b1290ee9273a282db24278f8d5, 65 Git-blob-verified individual ZIPs; consolidated ZIP excluded','checks':['source ZIP Git-blob SHA, SHA-256 and CRC','current native schemas per emitted document','native compilation and independent compiled-operand verification','1072 retained six-source primary source proofs matched by Assessment and full program hashes','all 1055 preceding six-source program hashes retained by six-source acceptance gate'],'original_source_validation':'Six anchor sources only via retained six-source gate; NOT RUN for other sources','independent_source_proof':'1072 six-source primary Rules only; NOT RUN for other sources','scanner_execution':'NOT RUN','counts':dict(counts),'total_rules':len(allrows),'summary':'summaries.json','ledger':'ledger.json / ledger.csv','reproduction':'Included scripts, source-pins.json and README.md','limitations':['Diagnostic candidate bundles are not accepted assessment packages','Compiled unproved candidates may include invalid/deprecated original closures; other 59 sources have not had original-source semantic validation','Four independent.sqlext source packages are held fail-closed; manual Rules remain separately counted','Only primary automated Assessment subsets; full policy, applicability and manual execution remain outside proof','Further secondary blockers may emerge after primary dependencies are resolved','Not a verified release or a complete lossless migration']}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
readme=['# DRAFT — NOT RUNTIME VERIFIED','','Designated all-65 NIWC checkpoint for [converter #251](https://github.com/vanderpol/scap-ng/issues/251).',f'Exact toolchain `{SHA}`; source revision `8c8e5dff860af6b1290ee9273a282db24278f8d5`.','All 65 individual original ZIPs are Git-blob/SHA-256 pinned; the consolidated ZIP is excluded.','','## What is delivered','','Actual generated JSON/YAML, diagnostic compiled bundles, every original Rule in JSON/CSV,','primary and overlapping secondary blockers, source graphs/hashes and exact generation scripts.','Four SQL Server packages containing nonstandard `independent.sqlext` remain package-level exceptions.','Their automated Rules are blocked and their manual Rules remain separately accounted.','','| Disjoint status | Rules |','| --- | ---: |']
readme += [f'| {s} | {n} |' for s,n in counts.items()];readme += [f'| Total | {len(allrows)} |','','Only 1,072 six-anchor primary Rules retain independent original-source proof and valid,','nondeprecated closures, with exact Assessment/program hashes checked. All 1,055 preceding','proof-floor program hashes remain unchanged. Other compiled output is explicitly unproved;','original XSD/Schematron and deprecation checks have NOT run for those sources.','Diagnostic bundles may contain rejected raw candidates and must not replace production packages.','No scanner has executed this output; applicability, complete policy and manual execution are unconverted.','','## Largest primary blockers','','Counts below are disjoint primary messages, not promised unlock counts. Secondary diagnostics overlap.','','| Primary message | Rules |','| --- | ---: |']
readme += [f'| {m.replace(chr(124),chr(92)+chr(124))} | {n} |' for m,n in primary.most_common(15)];readme += ['','Source catalog binding failures are preserved, not repaired. `all_exist`, function/dataflow,','import/export binding and acquisition/existence semantics require their existing approved contracts','or coordination through #255. Unavailable platform capabilities are not silently activated.','','## Reproduction','','Use a clean checkout of the exact toolchain, Python 3.12 and the pinned dependencies recorded','in the repository workflows (PyYAML, jsonschema, lxml). Place included scripts and','`niwc-65-source-tree.json` in a working directory. Recover ZIPs at `niwc-65-inputs/` using','`recover_65_sources.py`; source Git blob SHA and byte length are checked before use.','','```sh','PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/path/to/scap-ng/tools python build_65_draft.py','```','','This rebuilds raw compiled/unproved draft output. The finalizer additionally requires the','separately generated six-source acceptance evidence and its exact checked receipt; it only','relabels evidence after matching full program hashes, never changes authored/native operands.','Those local inputs are indexed in the source repository recovery checkpoint. To reproduce','the six-source proof gate, use `tools/verify_v04_direct_scope.py` with the six pinned inputs.','','Raw generation, verification and reuse are distinct; do not infer runtime acceptance from any stage.']
(OUT/'README.md').write_text('\n'.join(readme)+'\n')
archive=ROOT/'niwc-65-draft-248895772.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(OUT.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(OUT))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None;count=len(z.infolist())
manifest['raw_payload']={'file':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'file_count':count};(ROOT/'niwc-65-publication-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'total_rules':len(allrows),'counts':dict(counts),'raw_payload':manifest['raw_payload']},indent=2))
