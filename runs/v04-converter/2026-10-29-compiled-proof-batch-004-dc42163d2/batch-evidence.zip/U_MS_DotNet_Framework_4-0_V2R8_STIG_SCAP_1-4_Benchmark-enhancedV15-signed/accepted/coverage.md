# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"BLOCKED": 3, "NOT_SELECTED": 9, "PROVED": 5}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_mil.disa.fso_rule_SV-225223r961038_rule | PROVED | [] |
| xccdf_mil.disa.fso_rule_SV-225224r961038_rule | PROVED | [] |
| xccdf_mil.disa.fso_rule_SV-225225r961038_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.fso_rule_SV-225226r961041_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.fso_rule_SV-225227r960936_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.fso_rule_SV-225228r1043178_rule | BLOCKED | original OVAL closure invalid/deprecated |
| xccdf_mil.disa.fso_rule_SV-225229r1188309_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.fso_rule_SV-225230r1117185_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.fso_rule_SV-225231r961038_rule | PROVED | [] |
| xccdf_mil.disa.fso_rule_SV-225232r1050651_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.fso_rule_SV-225233r1117179_rule | BLOCKED | original OVAL closure invalid/deprecated |
| xccdf_mil.disa.fso_rule_SV-225234r1188289_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.fso_rule_SV-225235r960891_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.fso_rule_SV-225236r1117179_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.fso_rule_SV-225237r1043178_rule | BLOCKED | original OVAL closure invalid/deprecated |
| xccdf_mil.disa.fso_rule_SV-225238r1069480_rule | PROVED | [] |
| xccdf_mil.disa.fso_rule_SV-284958r1208187_rule | PROVED | [] |
