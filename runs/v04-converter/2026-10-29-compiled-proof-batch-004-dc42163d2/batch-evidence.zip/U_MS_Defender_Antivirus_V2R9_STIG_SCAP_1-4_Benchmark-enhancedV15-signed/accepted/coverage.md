# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"NOT_SELECTED": 8, "PROVED": 59}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_mil.disa.stig_rule_SV-213426r961197_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213427r961197_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213428r1192794_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213429r1207390_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213430r1207392_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213431r1207394_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213432r961092_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213433r1192798_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213434r1134051_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213435r961092_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213436r1192799_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213437r960921_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213438r960921_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213439r961089_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213440r961092_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213441r1192800_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213442r1192801_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213443r1192802_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213444r961089_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213445r1192803_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213446r961092_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213447r1192804_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213448r1192805_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213449r960852_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213450r961191_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213451r961092_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213452r1192806_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213453r1192807_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213454r961161_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213455r961086_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213456r961092_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-213457r961092_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-213458r961092_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-213459r961092_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-213460r961092_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-213461r961092_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-213462r961092_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-213463r961092_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-213464r961086_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213465r961086_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213466r961086_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278647r1192808_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278648r1192809_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278649r1192810_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278650r1192811_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278651r1192812_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278652r1192813_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278653r1192814_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278654r1192815_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278655r1192816_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278656r1192817_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278658r1207388_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278659r1192819_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278660r1192820_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278661r1192821_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278662r1192822_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278668r1192823_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278669r1192824_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278672r1192825_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278674r1192826_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278675r1192827_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278676r1192828_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278677r1192829_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278678r1192830_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278679r1192831_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278680r1192832_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-278863r1192833_rule | PROVED | [] |
