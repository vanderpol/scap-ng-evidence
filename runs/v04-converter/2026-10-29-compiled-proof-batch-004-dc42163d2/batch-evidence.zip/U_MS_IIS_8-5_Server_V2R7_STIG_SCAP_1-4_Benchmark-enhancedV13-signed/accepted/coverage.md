# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"BLOCKED": 1, "NOT_SELECTED": 26, "PROVED": 15, "UNVERIFIABLE/UNSUPPORTED": 1}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214400r879562_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214401r879562_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214402r879566_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214403r879567_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214404r879568_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214405r879578_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214406r879582_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214407r879587_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214408r879587_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214409r879587_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214410r879587_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214411r879587_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214412r879587_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214413r879587_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214414r879587_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214415r879612_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214416r879627_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214417r879631_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214418r879631_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214419r879638_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214420r879638_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214421r879640_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214422r879642_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214423r879652_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214424r879655_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214425r879655_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214428r879693_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214429r879717_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:navy.navwar.niwcatlantic.scc.ms.iis.8.5.server:tst:310", "native_test": "verify-unspecified-objects-are-not-assigned-to-acl-open-explorer-and-n-6a0c85d6-test", "reason": "Set/Filter/behavior collection proof unavailable: oval:navy.navwar.niwcatlantic.scc.ms.iis.8.5.server:obj:317"}, {"source_test": "oval:navy.navwar.niwcatlantic.scc.ms.iis.8.5.server:tst:311", "native_test": "file-perm-assigned-to-users-group-for-inetpub-directory-open-explorer-bbde4ed0-test", "reason": "Set/Filter/behavior collection proof unavailable: oval:navy.navwar.niwcatlantic.scc.ms.iis.8.5.server:obj:317"}, {"source_test": "oval:navy.navwar.niwcatlantic.scc.ms.iis.8.5.server:tst:312", "native_test": "file-perm-assigned-to-all-application-packages-for-inetpub-directory-o-4b65f96a-test", "reason": "Set/Filter/behavior collection proof unavailable: oval:navy.navwar.niwcatlantic.scc.ms.iis.8.5.server:obj:317"}] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214430r879730_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214431r879753_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214432r879756_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214433r879756_rule | BLOCKED | original OVAL closure invalid/deprecated |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214434r879806_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214435r879810_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214436r903078_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214437r879810_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214438r879887_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214440r879887_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214441r881085_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214442r879511_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-228573r879587_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-256987r903134_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-258446r928857_rule | NOT_SELECTED | [] |
