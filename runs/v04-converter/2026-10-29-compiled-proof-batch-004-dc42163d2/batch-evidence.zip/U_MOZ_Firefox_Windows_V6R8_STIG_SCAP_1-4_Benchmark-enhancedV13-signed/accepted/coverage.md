# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"BLOCKED": 1, "NOT_SELECTED": 1, "PROVED": 31}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_mil.disa.stig_rule_SV-251545r1117151_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-251546r1201983_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251547r1067550_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251548r1067552_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251549r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251550r961194_rule | BLOCKED | original OVAL closure invalid/deprecated |
| xccdf_mil.disa.stig_rule_SV-251551r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251552r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251553r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251554r1067554_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251555r1067556_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251557r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251558r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251559r961167_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251560r1067559_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251562r1156569_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251563r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251564r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251565r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251566r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251567r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251568r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251569r1067561_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251570r1067563_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251571r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251572r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251573r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251577r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251578r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251580r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251581r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-252881r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-252909r960963_rule | PROVED | [] |
