# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"NOT_SELECTED": 1, "PROVED": 25}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_mil.disa.stig_rule_SV-213168r395811_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213169r395811_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213170r395811_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213171r395811_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213172r395811_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213173r395811_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213174r395811_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213175r395811_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213176r395850_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213177r766574_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213178r395853_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213179r395853_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213180r395853_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213181r395853_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213182r395853_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213183r395853_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213184r395853_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213185r395853_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213186r395853_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213187r395853_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213188r400006_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213189r400006_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213190r400378_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213191r400378_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213192r400525_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-213193r400876_rule | PROVED | [] |
