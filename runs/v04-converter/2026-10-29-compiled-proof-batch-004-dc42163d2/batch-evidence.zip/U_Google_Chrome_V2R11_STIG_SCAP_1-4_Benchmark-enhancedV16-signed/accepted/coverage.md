# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"NOT_SELECTED": 2, "PROVED": 19, "UNVERIFIABLE/UNSUPPORTED": 25}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_mil.disa.stig_rule_SV-221558r960804_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240001", "native_test": "disable-firewall-traversal-8ff62d5e-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221559r961083_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240002", "native_test": "disable-tracking-user-s-location-6ff604f0-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221561r960963_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240004", "native_test": "disable-pop-ups-876f816c-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221562r960879_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240005", "native_test": "extensions-installation-are-blocklisted-by-default-51c3f40f-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221563r1015468_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240006", "native_test": "extensions-that-are-approved-for-use-are-allowlisted-42634452-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221564r960963_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240007", "native_test": "set-default-search-provider-name-c48f7084-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221565r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221566r960963_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240009", "native_test": "enable-default-search-provider-50006cde-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221567r960963_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240011", "native_test": "disable-password-manager-d0076a15-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221570r960921_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240017", "native_test": "disable-background-processing-e0d7bbd3-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221571r987620_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240020", "native_test": "disable-google-data-synchronization-0fdd03e1-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221572r960963_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:2400211", "native_test": "the-url-protocol-schema-javascript-is-disabled-5bdd076f-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221573r987620_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240023", "native_test": "disable-cloud-print-sharing-9206abe5-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221574r961863_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221575r960963_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240026", "native_test": "disable-google-metrics-reporting-249eb099-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221576r960963_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240027", "native_test": "enable-search-suggestion-4add1e6e-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221577r960963_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240029", "native_test": "password-history-var-f629cea5-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221578r960864_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240030", "native_test": "disable-incognito-mode-dbac3a96-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221579r961893_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240037", "native_test": "perform-online-revocation-checks-1a732fb8-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221580r961083_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240038", "native_test": "safe-browsing-is-enabled-d1aa656c-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221581r961128_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:240039", "native_test": "save-browser-history-d3ac5869-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221584r961683_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-221586r960879_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221587r960879_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:640053", "native_test": "prompt-for-download-location-65ac439d-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221588r1106670_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221590r961083_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:66005700", "native_test": "check-safebrowsingextendedreportingenabled-value-6a702297-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221591r960963_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:67005800", "native_test": "webusb-must-be-disabled-75f7b14b-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221594r960963_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:52006300", "native_test": "google-cast-must-be-disabled-95be6d57-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221595r960963_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:66005500", "native_test": "autoplay-is-disabled-a8bda58c-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-221596r961092_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-221597r961083_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221598r961083_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-221599r961167_rule | UNVERIFIABLE/UNSUPPORTED | [{"source_test": "oval:mil.disa.stig.chrome:tst:68006200", "native_test": "chrome-developer-tools-availability-must-be-disallowed-8f8fb404-test", "reason": "registry type proof unavailable"}] |
| xccdf_mil.disa.stig_rule_SV-226401r961083_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-226402r961083_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-226403r961083_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-226404r961083_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-241787r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-245538r961470_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-245539r960864_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-275780r1106603_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-275781r1106671_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-275782r1106672_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-275783r1106612_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-275784r1106615_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-275785r1106673_rule | PROVED | [] |
