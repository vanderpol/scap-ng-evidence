# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"NOT_SELECTED": 34, "PROVED": 15}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214444r879511_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214445r879511_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214446r903081_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214447r903084_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214448r879562_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214449r879562_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214450r879566_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214451r879567_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214452r879568_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214454r879587_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214455r903087_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214456r903089_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214457r879587_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214459r879588_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214460r903091_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214461r879631_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214462r879639_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214463r879643_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214464r879650_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214465r879650_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214466r879650_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214467r879650_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214468r903093_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214469r903095_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214470r879652_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214472r879655_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214473r903097_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214474r879673_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214475r879673_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214476r879693_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214477r879730_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214478r879756_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214479r879798_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214480r879800_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214481r879810_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214482r903100_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214483r903103_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214484r879887_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214485r879887_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214488r881088_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214489r879887_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214490r879887_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214491r879887_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214492r879887_rule | PROVED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214493r879587_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214494r879587_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214495r879587_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-214496r879887_rule | NOT_SELECTED | [] |
| xccdf_navy.navwar.niwcatlantic.scc.ms.iis_rule_SV-258445r928856_rule | NOT_SELECTED | [] |
