# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"NOT_SELECTED": 4, "PROVED": 19}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_mil.disa.stig_rule_SV-213117r766511_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213118r766514_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213119r766517_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213120r766520_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213121r766523_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213122r766526_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213123r766529_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213124r766532_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213126r766535_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-213127r766538_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213128r766541_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213129r400525_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-213130r766544_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213131r766547_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213132r766550_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213133r766553_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213134r766556_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213135r766559_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213136r766562_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213137r766565_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-213138r766568_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-213139r766571_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-245874r766580_rule | NOT_SELECTED | [] |
