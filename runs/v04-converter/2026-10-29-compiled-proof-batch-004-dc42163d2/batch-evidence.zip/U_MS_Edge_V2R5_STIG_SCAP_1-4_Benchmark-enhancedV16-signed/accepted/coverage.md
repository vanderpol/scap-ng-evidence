# Verified primary OVAL upgrade

Primary OVAL subset; applicability inventoried, not proved; no scanner acceptance

Counts: `{"NOT_SELECTED": 5, "PROVED": 56}`.

Only PROVED closures enter primary-subset.scapng. Full source/check/dependency
hashes and exact blockers are in acceptance.json; applicability remains unproved.

| Source Rule | Outcome | Diagnostic |
| --- | --- | --- |
| xccdf_mil.disa.stig_rule_SV-235719r1156558_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235720r960852_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235721r960852_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235722r960852_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-235723r960864_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235724r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235725r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235726r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235727r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235728r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235729r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235730r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235731r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235732r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235733r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235734r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235735r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235736r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235737r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235738r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235739r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235740r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235741r1007485_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235742r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235743r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235744r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235745r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235746r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235747r961038_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235748r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235749r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235750r960864_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235751r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235752r1156563_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235753r1015297_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-235754r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235755r961479_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-235756r961521_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235758r1117151_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-235760r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235761r1043177_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235763r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235764r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235765r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235766r1051115_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235767r960972_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235768r1015298_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235769r960981_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235770r960984_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235771r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235772r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235773r960993_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-235774r1015299_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-246736r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-251694r960963_rule | NOT_SELECTED | [] |
| xccdf_mil.disa.stig_rule_SV-260465r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-260466r960963_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-260467r960864_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-266981r1169858_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-279940r1156561_rule | PROVED | [] |
| xccdf_mil.disa.stig_rule_SV-283439r1192850_rule | PROVED | [] |
